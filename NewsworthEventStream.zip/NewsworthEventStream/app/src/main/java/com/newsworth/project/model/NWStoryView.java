package com.newsworth.project.model;

import java.io.Serializable;
import java.util.List;

public class NWStoryView implements Serializable {

       private static final long serialVersionUID = -5426326295549601810L;
       private String storyId;
       private String userNwId;
       private String title;
       private String description;
       private Location location;
       private String thumbnail;
       private String time;

       private List<NWMediaLocInfo> mediaLocInfo;

       private int likeCount;
       private boolean likeFlag;

       private int commentCount;
       private boolean bookmarkFlag;

       public NWStoryView() {
              super();
       }

       public NWStoryView(String storyId, String userNwId, String title, String description, Location location,
                     String thumbnail, String time, List<NWMediaLocInfo> mediaLocInfo, int likeCount, boolean likeFlag,
                     int commentCount, boolean bookmarkFlag) {
              super();
              this.storyId = storyId;
              this.userNwId = userNwId;
              this.title = title;
              this.description = description;
              this.location = location;
              this.thumbnail = thumbnail;
              this.time = time;
              this.mediaLocInfo = mediaLocInfo;
              this.likeCount = likeCount;
              this.likeFlag = likeFlag;
              this.commentCount = commentCount;
              this.bookmarkFlag = bookmarkFlag;
       }

       public String getStoryId() {
              return storyId;
       }

       public void setStoryId(String storyId) {
              this.storyId = storyId;
       }

       public String getUserNwId() {
              return userNwId;
       }

       public void setUserNwId(String userNwId) {
              this.userNwId = userNwId;
       }

       public String getTitle() {
              return title;
       }

       public void setTitle(String title) {
              this.title = title;
       }

       public String getDescription() {
              return description;
       }

       public void setDescription(String description) {
              this.description = description;
       }

       public Location getLocation() {
              return location;
       }

       public void setLocation(Location location) {
              this.location = location;
       }

       public String getThumbnail() {
              return thumbnail;
       }

       public void setThumbnail(String thumbnail) {
              this.thumbnail = thumbnail;
       }

       public String getTime() {
              return time;
       }

       public void setTime(String time) {
              this.time = time;
       }

       public List<NWMediaLocInfo> getMediaLocInfo() {
              return mediaLocInfo;
       }

       public void setMediaLocInfo(List<NWMediaLocInfo> mediaLocInfo) {
              this.mediaLocInfo = mediaLocInfo;
       }

       public int getLikeCount() {
              return likeCount;
       }

       public void setLikeCount(int likeCount) {
              this.likeCount = likeCount;
       }

       public boolean isLikeFlag() {
              return likeFlag;
       }

       public void setLikeFlag(boolean likeFlag) {
              this.likeFlag = likeFlag;
       }

       public int getCommentCount() {
              return commentCount;
       }

       public void setCommentCount(int commentCount) {
              this.commentCount = commentCount;
       }

       public boolean isBookmarkFlag() {
              return bookmarkFlag;
       }

       public void setBookmarkFlag(boolean bookmarkFlag) {
              this.bookmarkFlag = bookmarkFlag;
       }

       @Override
       public String toString() {
              return "NWStoryView [storyId=" + storyId + ", userNwId=" + userNwId + ", title=" + title + ", description="
                           + description + ", location=" + location + ", thumbnail=" + thumbnail + ", time=" + time
                           + ", mediaLocInfo=" + mediaLocInfo + ", likeCount=" + likeCount + ", likeFlag=" + likeFlag
                           + ", commentCount=" + commentCount + ", bookmarkFlag=" + bookmarkFlag + "]";
       }

}
