package com.newsworth.project.model;

import java.io.Serializable;

public class StoryContext implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2651118630313971113L;
	
	private String title;
	private String categoryId;
	private String description;
	private String publishUnder;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCategory() {
		return categoryId;
	}
	public void setCategory(String category) {
		this.categoryId = category;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPublishUnder() {
		return publishUnder;
	}
	public void setPublishUnder(String publishUnder) {
		this.publishUnder = publishUnder;
	}
	public StoryContext(String title, String category, String description, String publishUnder) {
		super();
		this.title = title;
		this.categoryId = category;
		this.description = description;
		this.publishUnder = publishUnder;
	}
	public StoryContext() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "StoryContext [title=" + title + ", category=" + categoryId + ", description=" + description
				+ ", publishUnder=" + publishUnder + "]";
	}
	
	
}
