package com.newsworth.project.model;

import java.io.Serializable;

public class AudioProfile implements Serializable {
    private static final long serialVersionUID= -8877134234236659303L;
    private String duration;
    private String quality;
    private Integer limitPerMonth;

    public AudioProfile(String duration, String quality, Integer limitPerMonth) {
        this.duration = duration;
        this.quality = quality;
        this.limitPerMonth = limitPerMonth;
    }

    public AudioProfile() {
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getQuality() {
        return quality;
    }

    public void setQuality(String quality) {
        this.quality = quality;
    }

    public Integer getLimitPerMonth() {
        return limitPerMonth;
    }

    public void setLimitPerMonth(Integer limitPerMonth) {
        this.limitPerMonth = limitPerMonth;
    }

    @Override
    public String toString() {
        return "AudioProfile{" +
                "duration='" + duration + '\'' +
                ", quality='" + quality + '\'' +
                ", limitPerMonth=" + limitPerMonth +
                '}';
    }
}
