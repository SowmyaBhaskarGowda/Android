package com.newsworth.project.model;

public class VidItem {

    private String title;
    private String desc;
    private String userId;

    public VidItem() {
    }

    public VidItem(String title, String desc, String userId) {

        this.title = title;
        this.desc = desc;
        this.userId = userId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    @Override
    public String toString() {
        return "VidItem{" +
                "title='" + title + '\'' +
                ", desc='" + desc + '\'' +
                ", userId='" + userId + '\'' +
                '}';
    }
}
