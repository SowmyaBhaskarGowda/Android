package com.newsworth.project.model;

import java.io.Serializable;

public class StoryObj  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3569766915447242145L;
	
	private String eventId;
	private String storyId;
	private String UserNwId;
	private String subscription;
	public String getEventId() {
		return eventId;
	}
	public void setEventId(String eventId) {
		this.eventId = eventId;
	}
	public String getStoryId() {
		return storyId;
	}
	public void setStoryId(String storyId) {
		this.storyId = storyId;
	}
	public String getUserNwId() {
		return UserNwId;
	}
	public void setUserNwId(String userNwId) {
		this.UserNwId = userNwId;
	}
	public String getSubscription() {
		return subscription;
	}
	public void setSubscription(String subscription) {
		this.subscription = subscription;
	}

	public StoryObj(String eventId, String storyId, String userNwId, String subscirption) {
		super();
		this.eventId = eventId;
		this.storyId = storyId;
		this.UserNwId = userNwId;
		this.subscription = subscirption;
	}
	@Override
	public String toString() {
		return "StoryObj [eventId=" + eventId + ", storyId=" + storyId + ", UserNwId=" + UserNwId + ", subscription="
				+ subscription + "]";
	}
	
}
