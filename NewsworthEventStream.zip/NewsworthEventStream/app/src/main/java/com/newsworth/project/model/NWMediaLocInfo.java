package com.newsworth.project.model;

import java.io.Serializable;

public class NWMediaLocInfo implements Serializable {
	
	private static final long serialVersionUID = -6099099585069386557L;
	
	private String storyId;
	private String mediaType;
	private String mediaFormat;
	private String mediaFileFrameResolution;
	private String nwGcdrFrameSize;
    private String mediaFilePath;
	private String mediaFileName;
	private Long  mediaFileSize;
	
	public String getStoryId() {
		return storyId;
	}
	public void setStoryId(String storyId) {
		this.storyId = storyId;
	}
	public String getMediaType() {
		return mediaType;
	}
	public void setMediaType(String mediaType) {
		this.mediaType = mediaType;
	}
	public String getMediaFormat() {
		return mediaFormat;
	}
	public void setMediaFormat(String mediaFormat) {
		this.mediaFormat = mediaFormat;
	}
	public String getMediaFileFrameResolution() {
		return mediaFileFrameResolution;
	}
	public void setMediaFileFrameResolution(String mediaFileFrameResolution) {
		this.mediaFileFrameResolution = mediaFileFrameResolution;
	}
	public String getNwGcdrFrameSize() {
		return nwGcdrFrameSize;
	}
	public void setNwGcdrFrameSize(String nwGcdrFrameSize) {
		this.nwGcdrFrameSize = nwGcdrFrameSize;
	}

	public String getMediaFileName() {
		return mediaFileName;
	}
	public void setMediaFileName(String mediaFileName) {
		this.mediaFileName = mediaFileName;
	}
	public Long getMediaFileSize() {
		return mediaFileSize;
	}
	public void setMediaFileSize(Long mediaFileSize) {
		this.mediaFileSize = mediaFileSize;
	}
	public String getMediaFilePath() {
		return mediaFilePath;
	}
	public void setMediaFilePath(String mediaFilePath) {
		this.mediaFilePath = mediaFilePath;
	}
	public NWMediaLocInfo(String storyId, String mediaType, String mediaFormat, String mediaFileFrameResolution,
						  String nwGcdrFrameSize, String mediaFilePath, String mediaFileName, Long mediaFileSize) {
		super();
		this.storyId = storyId;
		this.mediaType = mediaType;
		this.mediaFormat = mediaFormat;
		this.mediaFileFrameResolution = mediaFileFrameResolution;
		this.nwGcdrFrameSize = nwGcdrFrameSize;
		this.mediaFilePath = mediaFilePath;
		this.mediaFileName = mediaFileName;
		this.mediaFileSize = mediaFileSize;
	}
	
	public NWMediaLocInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "NWMediaLocInfo [storyId=" + storyId + ", mediaType=" + mediaType + ", mediaFormat=" + mediaFormat
				+ ", mediaFileFrameResolution=" + mediaFileFrameResolution + ", nwGcdrFrameSize=" + nwGcdrFrameSize
				+ ", mediaFilePath=" + mediaFilePath + ", mediaFileName=" + mediaFileName + ", mediaFileSize="
				+ mediaFileSize + "]";
	}
	
	
	
}
