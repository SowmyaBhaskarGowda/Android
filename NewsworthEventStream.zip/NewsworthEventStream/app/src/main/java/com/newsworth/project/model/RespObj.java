package com.newsworth.project.model;

/**
 * Created by Bhaskar on 12-01-2018.
 */

public class RespObj {


    private String message;
    private int code;

    public RespObj() {
    }

    public RespObj(String message, int code) {

        this.message = message;
        this.code = code;
    }

    public String getMessage() {

        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }
}
