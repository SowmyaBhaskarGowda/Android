package com.newsworth.project.model;

import java.io.Serializable;

public class Network  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7320764115907310226L;
	
	private String  countryCode;
	private String country;
	private String operator;
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}

	public Network(String countryCode, String country, String operator) {
		super();
		this.countryCode = countryCode;
		this.country = country;
		this.operator = operator;
	}
	
	public Network() {
		super();
	}
	@Override
	public String toString() {
		return "Network [countryCode=" + countryCode + ", country=" + country + ", operator=" + operator + "]";
	}
	
	

}
