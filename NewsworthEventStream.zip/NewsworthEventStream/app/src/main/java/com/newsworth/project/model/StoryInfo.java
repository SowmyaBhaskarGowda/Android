package com.newsworth.project.model;

import java.io.Serializable;

public class StoryInfo implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -7830321741316509532L;


    private StoryObj storyobj;
    private StoryContext storyContext;
    private StoryMediaInfo storyMediaInfo;
    private StoryDevice storyDevice;

    public StoryObj getStoryobj() {
        return storyobj;
    }

    public void setStoryobj(StoryObj storyobj) {
        this.storyobj = storyobj;
    }

    public StoryContext getStoryContext() {
        return storyContext;
    }

    public void setStoryContext(StoryContext storyContext) {
        this.storyContext = storyContext;
    }

    public StoryMediaInfo getStoryMediaInfo() {
        return storyMediaInfo;
    }

    public void setStoryMediaInfo(StoryMediaInfo storyMediaInfo) {
        this.storyMediaInfo = storyMediaInfo;
    }

    public StoryDevice getStoryDevice() {
        return storyDevice;
    }

    public void setStoryDevice(StoryDevice storyDevice) {
        this.storyDevice = storyDevice;
    }

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    public StoryInfo(StoryObj storyobj, StoryContext storyContext, StoryMediaInfo storyMediaInfo,
                     StoryDevice storyDevice) {
        super();
        this.storyobj = storyobj;
        this.storyContext = storyContext;
        this.storyMediaInfo = storyMediaInfo;
        this.storyDevice = storyDevice;

    }

    public StoryInfo() {
        super();
        // TODO Auto-generated constructor stub
    }

    @Override
    public String toString() {
        return "StoryInfo [storyobj=" + storyobj + ", storyContext=" + storyContext + ", storyMediaInfo="
                + storyMediaInfo + ", storyDevice=" + storyDevice+ "]";
    }


}
