package com.newsworth.project.model;

import java.util.List;

public class ElasticsearchResponse {
                private String storyId;
                private String userNwId;
                private String title;
                private String description;
                private String location;
                private List<NWMediaLocInfo> mediaLocInfo;

                public ElasticsearchResponse() {
                                super();

                }

                public String getStoryId() {
                                return storyId;
                }

                public void setStoryId(String storyId) {
                                this.storyId = storyId;
                }

                public String getUserNwId() {
                                return userNwId;
                }

                public void setUserNwId(String userNwId) {
                                this.userNwId = userNwId;
                }

                public List<NWMediaLocInfo> getMediaLocInfo() {
                                return mediaLocInfo;
                }

                public void setMediaLocInfo(List<NWMediaLocInfo> mediaLocInfo) {
                                this.mediaLocInfo = mediaLocInfo;
                }

                public String getTitle() {
                                return title;
                }

                public void setTitle(String title) {
                                this.title = title;
                }

                public String getDescription() {
                                return description;
                }

                public void setDescription(String description) {
                                this.description = description;
                }

                public String getLocation() {
                                return location;
                }

                public void setLocation(String location) {
                                this.location = location;
                }

                @Override
                public String toString() {
                                return "ElasticsearchResponse [UserNwId=" + userNwId + ", title=" + title + ", description=" + description
                                                                + ", location=" + location + ", mediaLocInfo=" + mediaLocInfo + "]";
                }

}
