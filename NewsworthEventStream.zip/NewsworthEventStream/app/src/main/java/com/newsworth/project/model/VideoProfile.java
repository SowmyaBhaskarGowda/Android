package com.newsworth.project.model;

import java.io.Serializable;

public class VideoProfile implements Serializable {

    private static final long serialVersionUID = -8877960734236659303L;
    private String duration;
    private String quality;
    private Integer limitPerMonth;

    public VideoProfile() {

    }

    public VideoProfile(String duration, String quality, Integer limitPerMonth) {
        this.duration = duration;
        this.quality = quality;
        this.limitPerMonth = limitPerMonth;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getQuality() {
        /* FRAME_SIZE_176x144
 FRAME_SIZE_320x240
 FRAME_SIZE_352x288
 FRAME_SIZE_640x480
 FRAME_SIZE_960x540
 FRAME_SIZE_1280x720
 FRAME_SIZE_1440x1080
 FRAME_SIZE_1920x1080
 FRAME_SIZE_3840x2160*/
        return quality;
    }

    public void setQuality(String quality) {
        this.quality = quality;
    }

    public Integer getLimitPerMonth() {
        return limitPerMonth;
    }

    public void setLimitPerMonth(Integer limitPerMonth) {
        this.limitPerMonth = limitPerMonth;
    }

    @Override
    public String toString() {
        return "VideoProfile{" +
                "duration='" + duration + '\'' +
                ", quality='" + quality + '\'' +
                ", limitPerMonth=" + limitPerMonth +
                '}';
    }
}
