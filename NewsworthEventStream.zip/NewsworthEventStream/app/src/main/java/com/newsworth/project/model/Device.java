package com.newsworth.project.model;

import java.io.Serializable;
import java.util.List;

public class Device implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7125596627639153895L;
	
	private String brand;
	private String  model;
	private String type;
	private List<Id> id;
	public Device(String brand, String model, String type, List<Id> id) {
		super();
		this.brand = brand;
		this.model = model;
		this.type = type;
		this.id = id;
	}
	public Device() {
		super();
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public List<Id> getId() {
		return id;
	}
	public void setId(List<Id> id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "Device [brand=" + brand + ", model=" + model + ", type=" + type + ", id=" + id + "]";
	}
	
	

}
