package com.newsworth.project.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class StoryDevice implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1707438751452914425L;
	
	private Timestamp timeStamp;
	private Location location;
	private Os os;
	private Device  device;
	private Network network;
	private Sim sim;

	public StoryDevice() {
	}

	public StoryDevice(Timestamp timeStamp, Location location, Os os, Device device, Network network, Sim sim) {
		this.timeStamp = timeStamp;
		this.location = location;
		this.os = os;
		this.device = device;
		this.network = network;
		this.sim = sim;
	}

	public Timestamp getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Timestamp timeStamp) {
		this.timeStamp = timeStamp;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public Os getOs() {
		return os;
	}

	public void setOs(Os os) {
		this.os = os;
	}

	public Device getDevice() {
		return device;
	}

	public void setDevice(Device device) {
		this.device = device;
	}

	public Network getNetwork() {
		return network;
	}

	public void setNetwork(Network network) {
		this.network = network;
	}

	public Sim getSim() {
		return sim;
	}

	public void setSim(Sim sim) {
		this.sim = sim;
	}

	@Override
	public String toString() {
		return "StoryDevice{" +
				"timeStamp=" + timeStamp +
				", location=" + location +
				", os=" + os +
				", device=" + device +
				", network=" + network +
				", sim=" + sim +
				'}';
	}
}
