package com.newsworth.project.model;

import java.io.Serializable;

public class Id implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8334702216709403473L;
	
	private String type;
	private String id;
	public Id(String type, String id) {
		super();
		this.type = type;
		this.id = id;
	}
	public Id() {
		super();
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Id [type=" + type + ", id=" + id + "]";
	}
	
	

}
