package com.newsworth.project.model;

import java.io.Serializable;

public class Sim  implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -264363527689704151L;

	private String identity;
	private int simStatusId;
	private String operator;
	private String simCountryCode;

    public Sim(String identity, int status, String operator, String simCountryCode) {

        this.identity = identity;
        this.simStatusId = status;
        this.operator = operator;
        this.simCountryCode = simCountryCode;
    }

    public Sim() {
    }

    public String getIdentity() {
        return identity;
    }

    public void setIdentity(String identity) {
        this.identity = identity;
    }

    public int getSimStatusId() {
        return simStatusId;
    }

    public void setSimStatusId(int simStatusId) {
        this.simStatusId = simStatusId;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getSimCountryCode() {
        return simCountryCode;
    }

    public void setSimCountryCode(String simCountryCode) {
        this.simCountryCode = simCountryCode;
    }

    @Override
    public String toString() {
        return "Sim{" +
                "identity='" + identity + '\'' +
                ", simStatusId='" + simStatusId + '\'' +
                ", operator='" + operator + '\'' +
                ", simCountryCode='" + simCountryCode + '\'' +
                '}';
    }
}
