package com.newsworth.project.model;

import java.io.Serializable;

public class NwEvent implements Serializable {
    private static final long serialVersionUID= -8877134234245659303L;

    private String eventId;
    private String eventName;

    public NwEvent(String eventId, String eventName) {
        this.eventId = eventId;
        this.eventName = eventName;
    }

    public NwEvent() {
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    @Override
    public String toString() {
        return "NwEvent{" +
                "eventId='" + eventId + '\'' +
                ", eventName='" + eventName + '\'' +
                '}';
    }
}
