package com.newsworth.project.model;

import android.content.Context;
import android.util.Log;

import com.google.android.gms.ads.identifier.AdvertisingIdClient;

public class AdIdAndroid {
    public static String getAdvertisingId(Context caller) throws Exception {
        String advertisingId=null;
        try {
            advertisingId = AdvertisingIdClient.getAdvertisingIdInfo(caller).getId();

        } catch (Throwable t) {

        }
        return advertisingId;
    }
}
