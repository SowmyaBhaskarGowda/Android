package com.newsworth.project.model;

import java.io.Serializable;

public class ImageProfile implements Serializable{

    private static final long serialVersionUID= -8877134746236659303L;
    private Integer framePerStory;
    private String quality;
    private Integer limitPerMonth;

    public ImageProfile() {
    }

    public ImageProfile(Integer framePerStory, String quality, Integer limitPerMonth) {
        this.framePerStory = framePerStory;
        this.quality = quality;
        this.limitPerMonth = limitPerMonth;
    }

    public Integer getFramePerStory() {
        return framePerStory;
    }

    public void setFramePerStory(Integer framePerStory) {
        this.framePerStory = framePerStory;
    }

    public String getQuality() {
        return quality;
    }

    public void setQuality(String quality) {
        this.quality = quality;
    }

    public Integer getLimitPerMonth() {
        return limitPerMonth;
    }

    public void setLimitPerMonth(Integer limitPerMonth) {
        this.limitPerMonth = limitPerMonth;
    }

    @Override
    public String toString() {
        return "ImageProfile{" +
                "framePerStory=" + framePerStory +
                ", quality='" + quality + '\'' +
                ", limitPerMonth=" + limitPerMonth +
                '}';
    }
}
