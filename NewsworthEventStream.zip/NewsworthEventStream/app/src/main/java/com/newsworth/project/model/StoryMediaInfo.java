package com.newsworth.project.model;

import java.io.Serializable;

public class StoryMediaInfo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3635771879935024081L;
	
	private String duration;
	private String format;
	private String type;
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getFormat() {
		return format;
	}
	public void setFormat(String format) {
		this.format = format;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public StoryMediaInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public StoryMediaInfo(String duration, String format, String type) {
		super();
		this.duration = duration;
		this.format = format;
		this.type = type;
	}
	@Override
	public String toString() {
		return "StoryMediaInfo [duration=" + duration + ", format=" + format + ", type=" + type + "]";
	}
	
	

}
