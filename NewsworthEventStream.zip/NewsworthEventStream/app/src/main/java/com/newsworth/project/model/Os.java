package com.newsworth.project.model;

import java.io.Serializable;

public class Os implements  Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2215025285837974039L;
	
	private String type;
	private String version;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	
	public Os() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Os(String type, String version) {
		super();
		this.type = type;
		this.version = version;
	}
	@Override
	public String toString() {
		return "Os [type=" + type + ", version=" + version + "]";
	}
	

}
