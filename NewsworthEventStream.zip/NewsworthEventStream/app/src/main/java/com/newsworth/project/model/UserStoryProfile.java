package com.newsworth.project.model;

import java.io.Serializable;

public class UserStoryProfile implements Serializable{
    private static final long serialVersionUID= -8877134299696654565L;
     private String userId;
    private String subscription;
    private VideoProfile videoProfile;
    private ImageProfile imageProfile;
    private AudioProfile audioProfile;
    public UserStoryProfile() {
    }

    public UserStoryProfile(String userId, String subscription, VideoProfile videoProfile, ImageProfile imageProfile) {
        this.userId = userId;
        this.subscription = subscription;
        this.videoProfile = videoProfile;
        this.imageProfile = imageProfile;
    }

    public UserStoryProfile(String userId, String subscription, VideoProfile videoProfile, ImageProfile imageProfile, AudioProfile audioProfile) {
        this.userId = userId;
        this.subscription = subscription;
        this.videoProfile = videoProfile;
        this.imageProfile = imageProfile;
        this.audioProfile = audioProfile;
    }

    @Override
    public String toString() {
        return "UserStoryProfile{" +
                "userId='" + userId + '\'' +
                ", subscription='" + subscription + '\'' +
                ", videoProfile=" + videoProfile +
                ", imageProfile=" + imageProfile +
                ", audioProfile=" + audioProfile +
                '}';
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getSubscriptionType() {
        return subscription;
    }

    public void setSubscriptionType(String subscriptionType) {
        this.subscription  = subscriptionType;
    }

    public VideoProfile getVideoProfile() {
        return videoProfile;
    }

    public void setVideoProfile(VideoProfile videoProfile) {
        this.videoProfile = videoProfile;
    }

    public ImageProfile getImageProfile() {
        return imageProfile;
    }

    public void setImageProfile(ImageProfile imageProfile) {
        this.imageProfile = imageProfile;
    }

    public String getSubscription() {
        return subscription;
    }

    public void setSubscription(String subscription) {
        this.subscription = subscription;
    }

    public AudioProfile getAudioProfile() {
        return audioProfile;
    }

    public void setAudioProfile(AudioProfile audioProfile) {
        this.audioProfile = audioProfile;
    }

}
