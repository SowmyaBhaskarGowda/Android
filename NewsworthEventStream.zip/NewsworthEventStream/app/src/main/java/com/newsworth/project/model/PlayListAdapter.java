package com.newsworth.project.model;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;
import java.util.List;

import newsworth.com.project.R;

public class PlayListAdapter extends BaseAdapter {

    List<NWStoryView> vidPlayList=new ArrayList<>();
    Context mContext;
    public PlayListAdapter(Context context, List<NWStoryView> playList) {
    this.vidPlayList=playList;
    this.mContext=context;
    }

    @Override
    public int getCount() {
        return vidPlayList.size();
    }


    @Override
    public Object getItem(int position) {
        return vidPlayList.get(position);
    }


    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView ==null){
            convertView=LayoutInflater.from(mContext).inflate(R.layout.activity_listview,parent,false);
        }
        NWStoryView vidItem= (NWStoryView) getItem(position);
        TextView tvTitle=(TextView) convertView.findViewById(R.id.vidTitle);
      //  TextView tvDesc=(TextView) convertView.findViewById(R.id.vidDesc);
        ImageView imageView=(ImageView) convertView.findViewById(R.id.list_image);
        tvTitle.setText(vidItem.getTitle());
       // tvDesc.setText(vidItem.getDescription());
        Bitmap bitmap;
        try{
            byte [] encodeByte=Base64.decode(vidItem.getThumbnail(),Base64.DEFAULT);
            bitmap=BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length);
            RequestOptions ro = new RequestOptions()
                    .fitCenter()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .placeholder(R.drawable.ic_videocam)
                    .override(256, 140)
                    .fitCenter();
            Glide.with(mContext).load(encodeByte).apply(ro).into(imageView);

        }catch(Exception e){
            e.getMessage();
            return null;
        }
        imageView.setImageBitmap(bitmap);
        return convertView;
    }
}
