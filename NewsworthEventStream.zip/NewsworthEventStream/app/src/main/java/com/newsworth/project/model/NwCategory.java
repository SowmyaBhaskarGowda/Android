package com.newsworth.project.model;

import java.io.Serializable;

public class NwCategory implements Serializable {
    private static final long serialVersionUID= -8877134234236645303L;

    private Integer newsCategoryId;
    private String newsCategoryName;

    public NwCategory(Integer newsCategoryId, String newsCategoryName) {
        this.newsCategoryId = newsCategoryId;
        this.newsCategoryName = newsCategoryName;
    }

    public NwCategory() {
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public Integer getNewsCategoryId() {
        return newsCategoryId;
    }

    public void setNewsCategoryId(Integer newsCategoryId) {
        this.newsCategoryId = newsCategoryId;
    }

    public String getNewsCategoryName() {
        return newsCategoryName;
    }

    public void setNewsCategoryName(String newsCategoryName) {
        this.newsCategoryName = newsCategoryName;
    }

    @Override
    public String toString() {
        return "NwCategory{" +
                "newsCategoryId=" + newsCategoryId +
                ", newsCategoryName='" + newsCategoryName + '\'' +
                '}';
    }
}
