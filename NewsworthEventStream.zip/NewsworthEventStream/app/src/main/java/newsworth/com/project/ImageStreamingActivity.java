package newsworth.com.project;

import android.Manifest;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.VideoView;

import com.newsworth.project.model.StoryInfo;
import com.newsworth.project.model.StoryMediaInfo;
import com.r0adkll.slidr.Slidr;
import com.wowza.gocoder.sdk.api.WowzaGoCoder;
import com.wowza.gocoder.sdk.api.configuration.WOWZMediaConfig;
import com.wowza.gocoder.sdk.api.data.WOWZData;
import com.wowza.gocoder.sdk.api.data.WOWZDataEvent;
import com.wowza.gocoder.sdk.api.data.WOWZDataMap;
import com.wowza.gocoder.sdk.api.devices.WOWZCamera;
import com.wowza.gocoder.sdk.api.devices.WOWZCameraView;
import com.wowza.gocoder.sdk.api.errors.WOWZError;
import com.wowza.gocoder.sdk.api.errors.WOWZStreamingError;
import com.wowza.gocoder.sdk.api.geometry.WOWZSize;
import com.wowza.gocoder.sdk.api.graphics.WOWZColor;
import com.wowza.gocoder.sdk.api.logging.WOWZLog;
import com.wowza.gocoder.sdk.api.status.WOWZStatus;

import newsworth.com.project.adapter.OnSwipeTouchListener;

public class ImageStreamingActivity extends CameraActivityBase {


    private static final String TAG = "";
    Float initialY, initialX;
    private StoryInfo storyInfo;
    private WOWZCameraView videoView;
    private static final String SDK_SAMPLE_APP_LICENSE_KEY = "GOSK-A945-010C-42CA-2B0C-4DE9";
    private WowzaGoCoder goCoder;
    private String storyId;
    @Override
    protected void onResume() {
        super.onResume();
        Bundle b = getIntent().getExtras();
        if (b != null) {
            storyInfo = (StoryInfo) getIntent().getExtras()
                    .getSerializable("storyInfo");

        }
        if (goCoder != null && videoView != null) {
            WOWZCamera activeCamera = videoView.getCamera();
            if (activeCamera != null && activeCamera.hasCapability(WOWZCamera.FOCUS_MODE_CONTINUOUS))
                activeCamera.setFocusMode(WOWZCamera.FOCUS_MODE_CONTINUOUS);
        }
        mRequiredPermissions = new String[] {
                Manifest.permission.CAMERA,
                Manifest.permission.RECORD_AUDIO
        };
        videoView.startPreview();
        System.out.println("Story being set  is : " + storyInfo);
        goCoderBroadcastConfig.setVideoFramerate(60);
        goCoderBroadcastConfig.setApplicationName("ImageCapture");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_streaming);
        goCoder = WowzaGoCoder.init(getApplicationContext(), SDK_SAMPLE_APP_LICENSE_KEY);
        videoView = findViewById(R.id.camera_preview);
/*        videoView.setCameraConfig(WOWZMediaConfig.FRAME_SIZE_640x480);
        videoView.setVideoBackgroundColor(WOWZColor.DARKGREY);*/
        videoView.startPreview();
        goCoderBroadcaster.registerDataEventListener("alteredStreamName", new WOWZDataEvent.EventListener() {
            @Override
            public WOWZDataMap onWZDataEvent(String eventName, WOWZDataMap payload) {
                WOWZData story=payload.get("streamName");

                storyId =new String();
                storyId=  story.toString();
                Log.d(TAG, "onWZDataEvent: storyId is "+storyId);
                return null;
            }
        });
        videoView.setOnTouchListener(new OnSwipeTouchListener(this) {

            @Override
            public void onSwipeRight() {
                Intent myIntent = new Intent(ImageStreamingActivity.this,
                        VideoStreamingActivity.class);
                storyInfo.setStoryMediaInfo(new StoryMediaInfo("", "mp4", "Video"));
                myIntent.putExtra("storyInfo", storyInfo);
                startActivity(myIntent);
            }

            @Override
            public void onSwipeLeft() {
                Intent myIntent = new Intent(ImageStreamingActivity.this,
                        AudioStreamingActivity.class);
                storyInfo.getStoryMediaInfo().setType("Audio");
                myIntent.putExtra("storyInfo", storyInfo);
                startActivity(myIntent);
            }
        });

    }
    public void onToggleBroadcast(View v) {
        Log.d(TAG, "onToggleBroadcast: ");
        if (getBroadcast() == null) return;

        if (getBroadcast().getStatus().isIdle()) {
            if (!goCoderBroadcastConfig.isVideoEnabled() && !goCoderBroadcastConfig.isAudioEnabled()) {
                Toast.makeText(this, "Unable to publish if both audio and video are disabled", Toast.LENGTH_LONG).show();
            }
            else{
                if(!goCoderBroadcastConfig.isAudioEnabled()){
                    Toast.makeText(this, "The audio stream is currently turned off", Toast.LENGTH_LONG).show();
                }

                if (!goCoderBroadcastConfig.isVideoEnabled()) {
                    Toast.makeText(this, "The video stream is currently turned off", Toast.LENGTH_LONG).show();
                }

                WOWZStreamingError configError = startBroadcast();
                new android.os.Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        onToggleBroadcast(mBtnBroadcast);
                        //    mBtnBroadcast.setBackgroundColor(getResources().getColor(R.color.broadCastStopColor));

                    }
                }, 5000/*Integer.parseInt(userStoryProfile.getVideoProfile().getDuration())*/);

                if (configError != null) {

                    WOWZLog.error(configError.getErrorDescription());
                }
            }
        } else {

            storyInfo.getStoryobj().setStoryId(storyId);
            Intent intent = new Intent(this, StoryPageActivity.class);
            intent.putExtra("nwStory", storyInfo);
            startActivity(intent);
            endBroadcast();
        }
    }
    @Override
    public void onWZCameraPreviewStarted(WOWZCamera wowzCamera, WOWZSize wowzSize, int i) {

    }

    @Override
    public void onWZCameraPreviewStopped(int i) {

    }

    @Override
    public void onWZCameraPreviewError(WOWZCamera wowzCamera, WOWZError wowzError) {

    }

    @Override
    public void onWZStatus(WOWZStatus wowzStatus) {

    }

    @Override
    public void onWZError(WOWZStatus wowzStatus) {

    }
}