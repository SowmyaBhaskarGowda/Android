package newsworth.com.project;

import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.MediaController;
import android.widget.VideoView;

import com.google.gson.Gson;
import com.newsworth.project.model.UserStoryProfile;
import com.wowza.gocoder.sdk.api.WowzaGoCoder;
import com.wowza.gocoder.sdk.api.configuration.WOWZMediaConfig;
import com.wowza.gocoder.sdk.api.data.WOWZDataScope;
import com.wowza.gocoder.sdk.api.mp4.WOWZMP4Util;
import com.wowza.gocoder.sdk.api.player.WOWZPlayerAPI;
import com.wowza.gocoder.sdk.api.player.WOWZPlayerConfig;
import com.wowza.gocoder.sdk.api.player.WOWZPlayerView;
import com.wowza.gocoder.sdk.api.status.WOWZStatus;
import com.wowza.gocoder.sdk.api.status.WOWZStatusCallback;

import java.util.Collections;
import java.util.List;

import newsworth.com.project.service.RestCallStory;

public class PlayerActivity extends AppCompatActivity {
    private static final String TAG = "PlayerActivity";
    private WowzaGoCoder goCoder;
    private WOWZPlayerView mStreamPlayerView = null;//1
    private WOWZPlayerConfig mStreamPlayerConfig = null;
    private String vidId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);
        goCoder = WowzaGoCoder.init(getApplicationContext(), "GOSK-9745-010F-C6F5-C502-A4E8");

        Bundle b = getIntent().getExtras();
        if (b != null) {
            vidId = (String) getIntent().getExtras()
                    .getSerializable("vidId");
        }
        mStreamPlayerView = (WOWZPlayerView) findViewById(R.id.vwStreamPlayer);//2
        mStreamPlayerConfig = new WOWZPlayerConfig();
        mStreamPlayerConfig.setIsPlayback(true);
        mStreamPlayerConfig.setHostAddress("192.168.90.76");
        mStreamPlayerConfig.setApplicationName("vod");
        mStreamPlayerConfig.setStreamName(vidId);
        mStreamPlayerConfig.setPortNumber(1935);
        mStreamPlayerView.setScaleMode(WOWZMediaConfig.FILL_VIEW);


        class StatusCallback implements WOWZStatusCallback {
            @Override
            public void onWZStatus(WOWZStatus wzStatus) {
            }
            @Override
            public void onWZError(WOWZStatus wzStatus) {
            }
        }
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                WOWZStatusCallback statusCallback = new StatusCallback();
                mStreamPlayerView.play(mStreamPlayerConfig, statusCallback);
            }
        }, 1000);

    }

    public void onTogglePlayPause(View view){
        Log.d(TAG, "onTogglePlayPause: Clicked");
        Log.d(TAG, "onTogglePlayPause: "+mStreamPlayerView.getCurrentStatus());
        if(mStreamPlayerView.isPlaying()) {
            mStreamPlayerView.pauseNetworkStack();
            mStreamPlayerView.onEnhancedSeekStart();
        }else
            mStreamPlayerView.unpauseNetworkStack();
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        mStreamPlayerView.stop();
    }
}
