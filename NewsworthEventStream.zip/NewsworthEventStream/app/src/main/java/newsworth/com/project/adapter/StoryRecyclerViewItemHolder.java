package newsworth.com.project.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import com.newsworth.project.model.NWStoryView;
import com.wowza.gocoder.sdk.api.player.WOWZPlayerView;

import newsworth.com.project.R;

public class StoryRecyclerViewItemHolder extends RecyclerView.ViewHolder {

    private TextView storyTitleText = null;
    private ImageView mStreamPlayerView = null;
    private String storyId;

    public String getStoryId() {
        return storyId;
    }

    public void setStoryId(String storyId) {
        this.storyId = storyId;
    }

    public StoryRecyclerViewItemHolder(View itemView) {
        super(itemView);

        if(itemView != null)
        {
            storyTitleText = (TextView)itemView.findViewById(R.id.card_view_image_title);
            mStreamPlayerView = (ImageView) itemView.findViewById(R.id.card_view_image);
        }
    }

    public TextView getStoryTitleText() {
        return storyTitleText;
    }

    public ImageView getmStreamPlayerView() {
        return mStreamPlayerView;
    }
}