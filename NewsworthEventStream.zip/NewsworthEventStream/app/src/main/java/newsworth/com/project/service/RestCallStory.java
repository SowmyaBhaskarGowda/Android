package newsworth.com.project.service;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;

import com.google.gson.Gson;
import com.newsworth.project.model.ElasticsearchResponse;
import com.newsworth.project.model.NWStoryView;
import com.newsworth.project.model.NwCategory;
import com.newsworth.project.model.NwEvent;
import com.newsworth.project.model.RespObj;
import com.newsworth.project.model.StoryInfo;
import com.newsworth.project.model.UserStoryProfile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RestCallStory {

    private static final String NIFI_URL = "http://192.168.90.204:8084/";
    private static final String MICRO_URL = "http://192.168.90.203:9051/";
    private static final String IMG_URL = "http://192.168.90.203:8080/";
    private static final String PLISTURL = "http://192.168.90.203:9051/";
    private static final String EVNTURL="http://192.168.90.203:9051/";
    private static final String CTGRYURL="http://192.168.90.203:9051/";
    private static UserStoryProfile userStoryProfile =new UserStoryProfile();

    public List<NwEvent> getNwEventLists(Context context){
        final SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);

        OkHttpClient.Builder okhttp = new OkHttpClient.Builder();
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);
        logging.setLevel(HttpLoggingInterceptor.Level.BASIC);
        logging.setLevel(HttpLoggingInterceptor.Level.HEADERS);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(EVNTURL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(okhttp.build())
                .build();

        UserService service = retrofit.create(UserService.class);
        Call<List<NwEvent>> call = service.getNwEventList();

        call.enqueue(new Callback<List<NwEvent>>() {

            @Override
            public void onResponse(Call<List<NwEvent>> call, Response<List<NwEvent>> response) {
                int status = response.code();
                List<NwEvent> resp = response.body();
                if (response.isSuccessful()) {
                    //  Toast.makeText(getApplicationContext(), "Succesful...!!! Status: " + status, Toast.LENGTH_LONG).show();
                    final SharedPreferences.Editor edit = preferences.edit();
                    List<NwEvent> nwEventList=new ArrayList<>();
                    nwEventList=resp;
                    Gson gson = new Gson();
                    String json = gson.toJson(nwEventList);
                    edit.putString("nwEventList", json);
                    edit.commit();

                } else
                    //   Toast.makeText(getApplicationContext(), "Something went wrong...!!!", Toast.LENGTH_LONG).show();
                    if (response == null) {
                        //  Toast.makeText(getApplicationContext(), "No response ...!!!", Toast.LENGTH_LONG).show();
                        System.out.println("SERVER CALL.... Nw Event List !!!!!! Response Was null ");
                    }
            }

            @Override
            public void onFailure(Call<List<NwEvent>> call, Throwable t) {
                System.out.println("SERVER CALL.... Nw Event List !!!!!! Request Failed........... :(  :(  :( ");
            }
        });

        return null;
    }
    public List<NwCategory> getNwCategoryLists(Context context){
        final SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);

        OkHttpClient.Builder okhttp = new OkHttpClient.Builder();
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);
        logging.setLevel(HttpLoggingInterceptor.Level.BASIC);
        logging.setLevel(HttpLoggingInterceptor.Level.HEADERS);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(CTGRYURL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(okhttp.build())
                .build();

        UserService service = retrofit.create(UserService.class);
        Call<List<NwCategory>> call = service.getNwCategoryList();

        call.enqueue(new Callback<List<NwCategory>>() {

            @Override
            public void onResponse(Call<List<NwCategory>> call, Response<List<NwCategory>> response) {
                int status = response.code();
                List<NwCategory> resp = response.body();
                if (response.isSuccessful()) {
                    //  Toast.makeText(getApplicationContext(), "Succesful...!!! Status: " + status, Toast.LENGTH_LONG).show();
                    final SharedPreferences.Editor edit = preferences.edit();
                    List<NwCategory> nwCatList=new ArrayList<>();
                    nwCatList=resp;
                    Gson gson = new Gson();
                    String json = gson.toJson(nwCatList);
                    edit.putString("nwCatList", json);
                    edit.commit();

                } else
                    //   Toast.makeText(getApplicationContext(), "Something went wrong...!!!", Toast.LENGTH_LONG).show();
                    if (response == null) {
                        //  Toast.makeText(getApplicationContext(), "No response ...!!!", Toast.LENGTH_LONG).show();
                        System.out.println("SERVER CALL.... Nw Event List !!!!!! Response Was null ");
                    }
            }

            @Override
            public void onFailure(Call<List<NwCategory>> call, Throwable t) {
                System.out.println("SERVER CALL.... Nw Event List !!!!!! Request Failed........... :(  :(  :( ");
            }
        });

        return null;
    }

    public void getUserStoryProfile(String userId,Context context) {

        final SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        OkHttpClient.Builder okhttp = new OkHttpClient.Builder();
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);
        logging.setLevel(HttpLoggingInterceptor.Level.BASIC);
        logging.setLevel(HttpLoggingInterceptor.Level.HEADERS);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(MICRO_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(okhttp.build())
                .build();

        UserService service = retrofit.create(UserService.class);
        Call<UserStoryProfile> call = service.getUserStoryProfile("4");


         call.enqueue(new Callback<UserStoryProfile>() {


            @Override
            public void onResponse(Call<UserStoryProfile> call, Response<UserStoryProfile> response) {
                int status = response.code();
                if (response.isSuccessful()) {

                    final SharedPreferences.Editor edit = preferences.edit();

                    userStoryProfile=(UserStoryProfile) response.body();
                    Gson gson = new Gson();
                    String json = gson.toJson(userStoryProfile);
                    edit.putString("userConf", json);
                    edit.commit();
                } else
                    System.out.println( "SERVER CALL.... micro service !!!!!! request failed...!!!" );

                    if (response == null) {
                        System.out.println("SERVER CALL.... Server call !!!!!! Response Was null ");
                    }
            }

            @Override
            public void onFailure(Call<UserStoryProfile> call, Throwable t) {

                //    Toast.makeText(getApplicationContext(), "Request Failedd........... :(  :(  :( ", Toast.LENGTH_LONG).show();
                System.out.println("SERVER CALL.... Server call !!!!!! Request Failedd........... :(  :(  :( ");
            }

        });


    }
public UserStoryProfile getUserConfig(){
        return userStoryProfile;

}

    public void getPlayList(Context context){
        final SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);

        OkHttpClient.Builder okhttp = new OkHttpClient.Builder();
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);
        logging.setLevel(HttpLoggingInterceptor.Level.BASIC);
        logging.setLevel(HttpLoggingInterceptor.Level.HEADERS);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(PLISTURL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(okhttp.build())
                .build();

        UserService service = retrofit.create(UserService.class);
        Call<List<NWStoryView>> call = service.getPlayList("satyajit63");

        call.enqueue(new Callback<List<NWStoryView>>() {

            @Override
            public void onResponse(Call<List<NWStoryView>> call, Response<List<NWStoryView>> response) {
                int status = response.code();
                List<NWStoryView> resp = response.body();
                if (response.isSuccessful()) {
                    //  Toast.makeText(getApplicationContext(), "Succesful...!!! Status: " + status, Toast.LENGTH_LONG).show();
                    final SharedPreferences.Editor edit = preferences.edit();
                    List<NWStoryView> playList=new ArrayList<>();
                    playList=resp;
                    Gson gson = new Gson();
                    String json = gson.toJson(playList);
                    edit.putString("playList", json);
                    edit.commit();

                } else
                    //   Toast.makeText(getApplicationContext(), "Something went wrong...!!!", Toast.LENGTH_LONG).show();
                    if (response == null) {
                        //  Toast.makeText(getApplicationContext(), "No response ...!!!", Toast.LENGTH_LONG).show();
                        System.out.println("SERVER CALL.... Play list !!!!!! Response Was null ");
                    }
            }

            @Override
            public void onFailure(Call<List<NWStoryView>> call, Throwable t) {
                System.out.println("SERVER CALL.... Play list !!!!!! Request Failed........... :(  :(  :( ");
            }
        });

    }
    public void ServerCall(StoryInfo userInfo) {

        OkHttpClient.Builder okhttp = new OkHttpClient.Builder();
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);
        logging.setLevel(HttpLoggingInterceptor.Level.BASIC);
        logging.setLevel(HttpLoggingInterceptor.Level.HEADERS);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(NIFI_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(okhttp.build())
                .build();

        UserService service = retrofit.create(UserService.class);
        Call<RespObj> call = service.userDetailInfo(userInfo);
        call.enqueue(new Callback<RespObj>() {

            @Override
            public void onResponse(Call<RespObj> call, Response<RespObj> response) {
                int status = response.code();
                RespObj resp = response.body();
                System.out.println("SERVER CALL.... Server call !!!!!! Response body " + resp);

                if (response.isSuccessful()) {

                } else
                 //   Toast.makeText(getApplicationContext(), "Something went wrong...!!!", Toast.LENGTH_LONG).show();
                if (response == null) {
                  //  Toast.makeText(getApplicationContext(), "No response ...!!!", Toast.LENGTH_LONG).show();
                    System.out.println("SERVER CALL.... NIFI !!!!!! Request Failure ");
                }
            }

            @Override
            public void onFailure(Call<RespObj> call, Throwable t) {

            //    Toast.makeText(getApplicationContext(), "Request Failedd........... :(  :(  :( ", Toast.LENGTH_LONG).show();
                System.out.println("SERVER CALL.... NIFI !!!!!! Request Failed........... :(  :(  :( ");
            }
        });
    }
}
