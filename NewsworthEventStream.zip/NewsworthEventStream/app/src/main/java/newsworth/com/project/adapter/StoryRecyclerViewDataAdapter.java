package newsworth.com.project.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DecodeFormat;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.newsworth.project.model.NWStoryView;
import com.wowza.gocoder.sdk.api.android.graphics.WOWZBitmap;
import com.wowza.gocoder.sdk.api.configuration.WOWZMediaConfig;
import com.wowza.gocoder.sdk.api.player.WOWZPlayerConfig;
import com.wowza.gocoder.sdk.api.player.WOWZPlayerView;
import com.wowza.gocoder.sdk.api.status.WOWZStatus;
import com.wowza.gocoder.sdk.api.status.WOWZStatusCallback;

import java.nio.charset.Charset;
import java.util.List;

import newsworth.com.project.PlayerActivity;
import newsworth.com.project.R;
import newsworth.com.project.VideoPlayListActivity;
import newsworth.com.project.adapter.StoryRecyclerViewItemHolder;

public class StoryRecyclerViewDataAdapter extends RecyclerView.Adapter<StoryRecyclerViewItemHolder> {
    private static final String TAG = "StoryRecyclerViewDataAd";
    List<NWStoryView> vidPlayList;
    private Context mContext;
    public StoryRecyclerViewDataAdapter(Context ctx, List<NWStoryView> itemPlayList) {
        this.vidPlayList=itemPlayList;
        this.mContext=ctx;
    }

    @NonNull
    @Override
    public StoryRecyclerViewItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Get LayoutInflater object.
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        // Inflate the RecyclerView item layout xml.
        View storyItemView = layoutInflater.inflate(R.layout.activity_card_view_item, parent, false);

        // Get story title text view object.
        final TextView storyTitleView = (TextView)storyItemView.findViewById(R.id.card_view_image_title);

        storyItemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get car title text.
                String carTitle = storyTitleView.getText().toString();
                // Create a snackbar and show it.
                System.out.println("You click " + carTitle +" image"+"  ::: ");

                for (NWStoryView vList:vidPlayList) {
                    if(vList.getTitle().equals(carTitle)) {
                        final String storyId = vList.getStoryId();
                        System.out.println("Story Id is : " + storyId + " :: " + vList.getUserNwId());
                        Intent myIntent = new Intent(mContext,
                                PlayerActivity.class);
                        myIntent.putExtra("vidId", storyId);
                        mContext.startActivity(myIntent);
                    }
                }

            }

        });

        // Create and return our custom Car Recycler View Item Holder object.
        StoryRecyclerViewItemHolder ret = new StoryRecyclerViewItemHolder(storyItemView);
        return ret;
    }

    @Override
    public void onBindViewHolder(@NonNull StoryRecyclerViewItemHolder holder, int position) {
        if(vidPlayList!=null) {
            // Get car item dto in list.
            NWStoryView storyItem = vidPlayList.get(position);
            System.out.println("==================>>>>>>>>"+storyItem);
            if(storyItem != null) {
                Bitmap bitmap;
                holder.setStoryId(storyItem.getStoryId());
                // Set car item title.
                holder.getStoryTitleText().setText(storyItem.getTitle());
                try{
                    BitmapFactory.Options options = new BitmapFactory.Options();
                    options.inJustDecodeBounds = true;
                    String thumbnail=storyItem.getThumbnail();
                    RequestOptions ro = new RequestOptions()
                            .fitCenter()
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .format(DecodeFormat.DEFAULT)
                            .placeholder(R.drawable.ic_videocam)
                            .dontAnimate()
                            .fitCenter();
                    Glide.with(mContext).load(thumbnail).into(holder.getmStreamPlayerView());
                }catch(Exception e){
                    e.getMessage();
                }
            }
        }
    }

    @Override
    public int getItemCount() {
        int ret = 0;
        if(vidPlayList!=null)
        {
            ret = vidPlayList.size();
        }
        return ret;
    }

}
