package newsworth.com.project;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MotionEvent;
import android.view.View;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.newsworth.project.model.NWStoryView;
import com.wowza.gocoder.sdk.api.WowzaGoCoder;
import com.wowza.gocoder.sdk.api.player.WOWZPlayerConfig;
import com.wowza.gocoder.sdk.api.player.WOWZPlayerView;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import newsworth.com.project.adapter.OnSwipeTouchListener;
import newsworth.com.project.adapter.StoryRecyclerViewDataAdapter;

public class StoryPlayListActivity extends AppCompatActivity {

    private List<NWStoryView> storyItemList;
    private Gson gson = new Gson();
    private String json;
    private WowzaGoCoder goCoder;
    private WOWZPlayerView mStreamPlayerView = null;//1
    private WOWZPlayerConfig mStreamPlayerConfig = null;
    private String vidId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story_play_list);
        goCoder = WowzaGoCoder.init(getApplicationContext(), "GOSK-9745-010F-C6F5-C502-A4E8");

        populatePlayList();
        // Create the recyclerview.
        RecyclerView storyRecyclerView = (RecyclerView)findViewById(R.id.card_view_recycler_list);
        // Create the grid layout manager with single columns.
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 1);
        // Set layout manager.
        storyRecyclerView.setLayoutManager(gridLayoutManager);

        // Create car recycler view data adapter with car item list.
        StoryRecyclerViewDataAdapter storyDataAdapter = new StoryRecyclerViewDataAdapter(this,storyItemList);
        // Set data adapter.
        storyRecyclerView.setAdapter(storyDataAdapter);



    }

    public void populatePlayList() {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);

        json = preferences.getString("playList", "");
        Type type=new TypeToken<List<NWStoryView>>(){}.getType();
        storyItemList= gson.fromJson(json,type);

        List<NWStoryView> vidItemLIst= new ArrayList<>();
        System.out.println(storyItemList);
        if(storyItemList==null){
            new android.os.Handler().postDelayed(new Runnable() {
                @Override
                public void run() {

                    storyItemList= Collections.singletonList(gson.fromJson(json, NWStoryView.class));
                    System.out.println(storyItemList);
                }
            }, 3000);
        }
    }
}
