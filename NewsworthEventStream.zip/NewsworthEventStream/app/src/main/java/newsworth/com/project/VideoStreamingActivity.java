package newsworth.com.project;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.app.ActivityCompat;
import android.support.v4.view.GestureDetectorCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.newsworth.project.model.StoryInfo;
import com.newsworth.project.model.StoryMediaInfo;
import com.r0adkll.slidr.Slidr;
import com.wowza.gocoder.sdk.api.WowzaGoCoder;
import com.wowza.gocoder.sdk.api.broadcast.WOWZBroadcast;
import com.wowza.gocoder.sdk.api.broadcast.WOWZBroadcastConfig;
import com.wowza.gocoder.sdk.api.configuration.WOWZMediaConfig;
import com.wowza.gocoder.sdk.api.data.WOWZData;
import com.wowza.gocoder.sdk.api.data.WOWZDataEvent;
import com.wowza.gocoder.sdk.api.data.WOWZDataItem;
import com.wowza.gocoder.sdk.api.data.WOWZDataMap;
import com.wowza.gocoder.sdk.api.data.WOWZDataScope;
import com.wowza.gocoder.sdk.api.devices.WOWZAudioDevice;
import com.wowza.gocoder.sdk.api.devices.WOWZCamera;
import com.wowza.gocoder.sdk.api.devices.WOWZCameraView;
import com.wowza.gocoder.sdk.api.errors.WOWZError;
import com.wowza.gocoder.sdk.api.errors.WOWZStreamingError;
import com.wowza.gocoder.sdk.api.geometry.WOWZSize;
import com.wowza.gocoder.sdk.api.logging.WOWZLog;
import com.wowza.gocoder.sdk.api.status.WOWZState;
import com.wowza.gocoder.sdk.api.status.WOWZStatus;

import newsworth.com.project.adapter.OnSwipeTouchListener;

public class VideoStreamingActivity extends CameraActivityBase{

    private StoryInfo userInfo;
    private String storyId;
    private static final String TAG = "VideoStreamingActivity";
    Float initialY,initialX;

    private static final int REQUEST_CAMERA=103;
    private static final int REQUEST_AUDIO=104;
    private static final int TXT_CAMERA=1;
    private static final int TXT_AUDIO=2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_streaming);
        Log.d(TAG, "onCreate: ");
        Bundle b = getIntent().getExtras();
        if (b != null) {
            userInfo = (StoryInfo) getIntent().getExtras()
                    .getSerializable("storyInfo");
        }

        mRequiredPermissions = new String[] {
                Manifest.permission.CAMERA,
                Manifest.permission.RECORD_AUDIO
        };
        goCoderBroadcaster.registerDataEventListener("alteredStreamName", new WOWZDataEvent.EventListener() {
            @Override
            public WOWZDataMap onWZDataEvent(String eventName, WOWZDataMap payload) {
                WOWZData story=payload.get("streamName");

              storyId =new String();
                storyId=  story.toString();
                return null;
            }
        });
    }
    public void onToggleBroadcast(View v) {
        Log.d(TAG, "onToggleBroadcast: ");
        if (getBroadcast() == null) return;

        if (getBroadcast().getStatus().isIdle()) {
            Log.d(TAG, "onToggleBroadcast: broadcast Status: "+getBroadcast().getStatus());
            if (!goCoderBroadcastConfig.isVideoEnabled() && !goCoderBroadcastConfig.isAudioEnabled()) {
                Toast.makeText(this, "Unable to publish if both audio and video are disabled", Toast.LENGTH_LONG).show();
            }
            else{
                if(!goCoderBroadcastConfig.isAudioEnabled()){
                    Toast.makeText(this, "The audio stream is currently turned off", Toast.LENGTH_LONG).show();
                }

                if (!goCoderBroadcastConfig.isVideoEnabled()) {
                    Toast.makeText(this, "The video stream is currently turned off", Toast.LENGTH_LONG).show();
                }

                WOWZStreamingError configError = startBroadcast();
                new android.os.Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        Log.d(TAG, "onToggleBroadcast: Stopping broadcast with Status: "+getBroadcast().getStatus());
                        userInfo.getStoryobj().setStoryId(storyId);
                        Intent intent = new Intent(VideoStreamingActivity.this, StoryPageActivity.class);
                        intent.putExtra("nwStory", userInfo);
                        endBroadcast();
                        startActivity(intent);

                    //    mBtnBroadcast.setBackgroundColor(getResources().getColor(R.color.broadCastStopColor));

                    }
                }, Integer.parseInt(userStoryProfile.getVideoProfile().getDuration()));


            }
        } else {
            Log.d(TAG, "onToggleBroadcast: broadcast Status: "+getBroadcast().getStatus());
            userInfo.getStoryobj().setStoryId(storyId);
            Intent intent = new Intent(this, StoryPageActivity.class);
            intent.putExtra("nwStory", userInfo);
            endBroadcast();
            startActivity(intent);

        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: ");
        if (this.hasDevicePermissionToAccess() && goCoder != null && mWZCameraView != null) {
            WOWZCamera activeCamera = mWZCameraView.getCamera();
            if (activeCamera != null && activeCamera.hasCapability(WOWZCamera.FOCUS_MODE_CONTINUOUS))
                activeCamera.setFocusMode(WOWZCamera.FOCUS_MODE_CONTINUOUS);
        }
        goCoderCameraView.setOnTouchListener(new OnSwipeTouchListener(this){

            @Override
            public void onSwipeRight() {
                Intent myIntent = new Intent(VideoStreamingActivity.this,
                        MainActivity.class);
                startActivity(myIntent);
            }

            @Override
            public void onSwipeLeft() {
                Intent myIntent = new Intent(VideoStreamingActivity.this,
                        ImageStreamingActivity.class);
                userInfo.setStoryMediaInfo(new StoryMediaInfo("", "png", "Image"));
                myIntent.putExtra("storyInfo", userInfo);
                startActivity(myIntent);
            }
        });

    }

    @Override
    public void onWZStatus(WOWZStatus wowzStatus) {

    }

    @Override
    public void onWZError(WOWZStatus wowzStatus) {

    }

    @Override
    public void onWZCameraPreviewStarted(WOWZCamera wowzCamera, WOWZSize wowzSize, int i) {

        Log.d(TAG, "onWZCameraPreviewStarted: ");

    }

    @Override
    public void onWZCameraPreviewStopped(int i) {

    }

    @Override
    public void onWZCameraPreviewError(WOWZCamera wowzCamera, WOWZError wowzError) {

    }
}
