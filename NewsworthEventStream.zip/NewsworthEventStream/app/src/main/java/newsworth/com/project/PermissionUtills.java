package newsworth.com.project;

import android.content.Context;
import android.content.SharedPreferences;

public class PermissionUtills {
    private Context context;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    public PermissionUtills(Context context) {
        this.context = context;
        sharedPreferences=context.getSharedPreferences(context.getString(R.string.permission_preference), Context.MODE_PRIVATE);
        editor=sharedPreferences.edit();
    }

    public void updatePermissionPreference(String permission){

        switch (permission){
            case "phone_state":
                editor.putBoolean(context.getString(R.string.permission_phone_state),true);
                editor.commit();
                break;
            case "course_location":
                editor.putBoolean(context.getString(R.string.permission_course_location),true);
                editor.commit();
                break;
            case "fine_location":
                editor.putBoolean(context.getString(R.string.permission_fine_location),true);
                editor.commit();
                break;
        }
    }

    public boolean checkPermissionPreference(String permission){
        boolean isShown=false;
        switch (permission){
            case "phone_state":
                isShown=sharedPreferences.getBoolean(context.getString(R.string.permission_phone_state),false);
                break;

            case "course_location":
                isShown=sharedPreferences.getBoolean(context.getString(R.string.permission_course_location),false);
                break;
            case "fine_location":
                isShown=sharedPreferences.getBoolean(context.getString(R.string.permission_fine_location),false);
                break;
        }
        return isShown;
    }
}
