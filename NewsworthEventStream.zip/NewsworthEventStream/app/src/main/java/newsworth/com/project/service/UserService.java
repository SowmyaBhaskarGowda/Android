package newsworth.com.project.service;


import com.newsworth.project.model.ElasticsearchResponse;
import com.newsworth.project.model.NWStoryView;
import com.newsworth.project.model.NwCategory;
import com.newsworth.project.model.NwEvent;
import com.newsworth.project.model.RespObj;
import com.newsworth.project.model.StoryInfo;
import com.newsworth.project.model.UserStoryProfile;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;

/**
 * Created by Bhaskar on 12-01-2018.
 */

public interface UserService {

    @Headers("content-type: application/json")
    @POST("/storyInfo")
    Call<RespObj> userDetailInfo(@Body StoryInfo userInfo);

    @Headers("content-type: application/json")
    @GET("/storyCreation/StoryProfile/{userId}")
    Call<UserStoryProfile> getUserStoryProfile(@Path("userId") String userId);

    @Headers("content-type: application/json")
    @GET("/storyCreation/storylist/videoPlaylist/{userNwId}")
    Call<List<NWStoryView>> getPlayList(@Path("userNwId") String userNwId);

    @Headers("content-type: application/json")
    @GET("/storyCreation/nwevent/getEvent")
    Call<List<NwEvent>> getNwEventList();

    @Headers("content-type: application/json")
    @GET("/storyCreation/nwcategory/getNewsCategory")
    Call<List<NwCategory>> getNwCategoryList();


}
