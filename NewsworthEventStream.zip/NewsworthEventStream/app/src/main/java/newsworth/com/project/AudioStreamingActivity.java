package newsworth.com.project;

import android.Manifest;
import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import com.newsworth.project.model.StoryInfo;
import com.r0adkll.slidr.Slidr;
import com.wowza.gocoder.sdk.api.data.WOWZData;
import com.wowza.gocoder.sdk.api.data.WOWZDataEvent;
import com.wowza.gocoder.sdk.api.data.WOWZDataMap;
import com.wowza.gocoder.sdk.api.data.WOWZDataScope;
import com.wowza.gocoder.sdk.api.devices.WOWZCamera;
import com.wowza.gocoder.sdk.api.errors.WOWZStreamingError;
import com.wowza.gocoder.sdk.api.logging.WOWZLog;
import com.wowza.gocoder.sdk.api.status.WOWZStatus;

public class AudioStreamingActivity extends AudioActivityBase {

    private StoryInfo storyInfo;
    private String storyId;
    @Override
    protected void onResume() {
        super.onResume();
        Bundle b = getIntent().getExtras();
        if (b != null) {
            storyInfo = (StoryInfo) getIntent().getExtras()
                    .getSerializable("storyInfo");

        }

        mRequiredPermissions = new String[] {
                Manifest.permission.RECORD_AUDIO
        };
        System.out.println("Story being set  is : " + storyInfo);
        goCoderBroadcastConfig.setApplicationName("AudioStream");
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_streaming);

        Slidr.attach(this);
        goCoderBroadcaster.registerDataEventListener("alteredStreamName", new WOWZDataEvent.EventListener() {
            @Override
            public WOWZDataMap onWZDataEvent(String eventName, WOWZDataMap payload) {
                System.out.println("Result recieved For Event Name:  "+eventName+"and the PayLoad is "+payload);
                WOWZData story=payload.get("streamName");

                storyId =new String();
                storyId=  story.toString();
                System.out.println("Result recieved For Event Name: "+storyId);
                return null;
            }
        });
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        System.out.println("AudioStreamingActivity:  OnTouchEvent ");
        return super.onTouchEvent(event);
    }

    public void onToggleBroadcast(View v) {
        if (getBroadcast() == null) return;

        if (getBroadcast().getStatus().isIdle()) {
            if (!goCoderBroadcastConfig.isVideoEnabled() && !goCoderBroadcastConfig.isAudioEnabled()) {
                Toast.makeText(this, "Unable to publish if both audio and video are disabled", Toast.LENGTH_LONG).show();
            }
            else{
                if(!goCoderBroadcastConfig.isAudioEnabled()){
                    Toast.makeText(this, "The audio stream is currently turned off", Toast.LENGTH_LONG).show();
                }


                WOWZStreamingError configError = startBroadcast();
   /*             new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        goCoderBroadcaster.sendDataEvent(WOWZDataScope.MODULE, "onEventData");

                    }
                }, Integer.parseInt(userStoryProfile.getVideoProfile().getDuration())/2);*/
                new android.os.Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        storyInfo.getStoryobj().setStoryId(storyId);
                        System.out.println(storyInfo);
                        Intent intent = new Intent(AudioStreamingActivity.this, StoryPageActivity.class);
                        intent.putExtra("nwStory", storyInfo);
                        endBroadcast();
                        startActivity(intent);
                    }
                }, Integer.parseInt(userStoryProfile.getVideoProfile().getDuration()));

                if (configError != null) {

                    WOWZLog.error(configError.getErrorDescription());
                }
            }
        } else {

            storyInfo.getStoryobj().setStoryId(storyId);
            System.out.println(storyInfo);
            Intent intent = new Intent(this, StoryPageActivity.class);
            intent.putExtra("nwStory", storyInfo);
            endBroadcast();
            startActivity(intent);

        }
    }

    @Override
    public void onWZStatus(WOWZStatus wowzStatus) {

    }

    @Override
    public void onWZError(WOWZStatus wowzStatus) {

    }
}
