package newsworth.com.project;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import com.newsworth.project.model.com.newsworth.project.config.GoCoderSDKPrefs;
import com.r0adkll.slidr.Slidr;
import com.wowza.gocoder.sdk.api.WowzaGoCoder;
import com.wowza.gocoder.sdk.api.devices.WOWZAudioDevice;
import com.wowza.gocoder.sdk.api.devices.WOWZCamera;
import com.wowza.gocoder.sdk.api.devices.WOWZCameraView;
import com.wowza.gocoder.sdk.api.errors.WOWZStreamingError;
import com.wowza.gocoder.sdk.api.graphics.WOWZColor;
import com.wowza.gocoder.sdk.api.logging.WOWZLog;
import com.wowza.gocoder.sdk.api.status.WOWZStatus;

import java.util.logging.Handler;

abstract public class CameraActivityBase extends GoCoderSDKActivityBase
        implements WOWZCameraView.PreviewStatusListener{
    private static final String TAG = "CameraActivityBase";
	protected WOWZCameraView goCoderCameraView;
    protected WOWZCameraView mWZCameraView  = null;
    protected WOWZAudioDevice mWZAudioDevice = null;
    protected Button mBtnBroadcast = null;
    Float initialY,initialX;
    private boolean mDevicesInitialized = false;
//System.out.println("GoCoderSDKActivityBase : goCoderBroadcastConfigs  : CameraActivityBase : "+goCoderBroadcastConfig.toString());
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate: ");
	}

	@Override
	protected void onResume() {
		super.onResume();
        Log.d(TAG, "onResume: ");
		if(goCoder !=null) {
            goCoderCameraView = (WOWZCameraView) findViewById(R.id.camera_preview);
            goCoderCameraView.setCameraConfig(getBroadcastConfig());
            goCoderCameraView.setVideoBackgroundColor(WOWZColor.DARKGREY);
            goCoderCameraView.startPreview();
        }

        this.hasDevicePermissionToAccess(new PermissionCallbackInterface() {

            @Override
            public void onPermissionResult(boolean result) {
                if (!mDevicesInitialized || result) {
                    initGoCoderDevices();
                }
            }
        });
	}


    protected void initUIControls() {
        Log.d(TAG, "initUIControls: ");
	    mBtnBroadcast= (Button)findViewById(R.id.broadcast_button);
        // The GoCoder SDK camera view
        goCoderCameraView = (WOWZCameraView) findViewById(R.id.camera_preview);//1

        if (goCoder == null )
            WOWZLog.error(WowzaGoCoder.getLastError().getErrorDescription());
    }
    protected void initGoCoderDevices() {
        Log.d(TAG, "initGoCoderDevices: ");
	    if (goCoder != null) {

            boolean videoIsInitialized = false;
            boolean audioIsInitialized = false;

            // Initialize the camera preview
            if(this.hasDevicePermissionToAccess(Manifest.permission.CAMERA)) {
                if (goCoderCameraView != null) {//2
                    WOWZCamera availableCameras[] = goCoderCameraView.getCameras();//3
                    // Ensure we can access to at least one camera
                    if (availableCameras.length > 0) {
                        // Set the video broadcaster in the broadcast config
                        getBroadcastConfig().setVideoBroadcaster(goCoderCameraView);//4
                        videoIsInitialized = true;

                    } else {
                        WOWZLog.error("Could not detect or gain access to any cameras on this device");
                        getBroadcastConfig().setVideoEnabled(false);
                    }
                } else {
                    getBroadcastConfig().setVideoEnabled(false);//1
                }
            }

            if(this.hasDevicePermissionToAccess(Manifest.permission.RECORD_AUDIO)) {
                // Initialize the audio input device interface
                mWZAudioDevice = new WOWZAudioDevice();

                // Set the audio broadcaster in the broadcast config
                getBroadcastConfig().setAudioBroadcaster(mWZAudioDevice);
                audioIsInitialized = true;
            }

            if(videoIsInitialized && audioIsInitialized)
                mDevicesInitialized = true;
        }
    }

    protected boolean syncUIControlState() {
        Log.d(TAG, "syncUIControlState: ");
	    boolean disableControls = (getBroadcast() == null ||
                !(getBroadcast().getStatus().isIdle() ||
                        getBroadcast().getStatus().isRunning()));
        boolean isStreaming = (getBroadcast() != null && getBroadcast().getStatus().isRunning());

        if (disableControls) {
            if (mBtnBroadcast != null) mBtnBroadcast.setEnabled(false);

        } else {
            if (mBtnBroadcast != null) {
                mBtnBroadcast.setEnabled(true);
            }
        }

        return disableControls;
    }

    //define callback interface
    interface PermissionCallbackInterface {

        void onPermissionResult(boolean result);
    }


}