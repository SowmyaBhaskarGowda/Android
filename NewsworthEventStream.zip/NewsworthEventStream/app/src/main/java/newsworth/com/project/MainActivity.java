package newsworth.com.project;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.MotionEventCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.newsworth.project.model.Device;
import com.newsworth.project.model.GPSTracker;
import com.newsworth.project.model.Id;
import com.newsworth.project.model.Location;
import com.newsworth.project.model.Network;
import com.newsworth.project.model.Os;
import com.newsworth.project.model.Sim;
import com.newsworth.project.model.StoryContext;
import com.newsworth.project.model.StoryDevice;
import com.newsworth.project.model.StoryInfo;
import com.newsworth.project.model.StoryMediaInfo;
import com.newsworth.project.model.StoryObj;
import com.r0adkll.slidr.Slidr;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import newsworth.com.project.service.RestCallStory;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private Button videoStream;
    private Button audioStream;
    private Button imageStream;
    private Button player;
    RestCallStory restCallStory = new RestCallStory();
    private PermissionUtills permissionUtills;
    private static final int REQUEST_PHONE_STATE=120;
    private static final int REQUEST_FINE_LOCATION=121;
    private static final int REQUEST_COURSE_LOCATION=123;
    private Context context = this;
    private static final int TXT_PHONE_STATE=1;
    private static final int TXT_FINE_LOCATION=2;
    private static final int TXT_COURSE_LOCATION=3;
    private final int MY_PERMISSIONS_REQUEST_READ_STATUS = 1;

    private StoryInfo storyInfo;
    GPSTracker gps;
    private TelephonyManager telephonyManager;
    Float initialY,initialX;
    private String provider;

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: ");
        restCallStory.getUserStoryProfile("5",this);
        restCallStory.getPlayList(this);
        restCallStory.getNwEventLists(this);
        restCallStory.getNwCategoryLists(this);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        Log.d(TAG, "onTouchEvent: ");
        int action = event.getActionMasked();
        switch (action) {

            case MotionEvent.ACTION_DOWN:
                initialX = event.getX();
                initialY = event.getY();

                break;

            case MotionEvent.ACTION_MOVE:
                Log.i(TAG, "onTouchEvent: PRESS ACTION_MOVE");
                break;

            case MotionEvent.ACTION_UP:
                float finalX = event.getX();
                float finalY = event.getY();
                Log.i(TAG, "onTouchEvent: PRESS ACTION_UP");

                if (initialX < finalX) {
                    Log.i(TAG, "onTouchEvent: SWIPE RIGHT");
                    Intent myIntent = new Intent(MainActivity.this,
                            StoryPlayListActivity.class);
                    startActivity(myIntent);
                }

                if (initialX > finalX) {
                    Log.i(TAG, "onTouchEvent: SWIPE LEFT");
                    Intent myIntent = new Intent(MainActivity.this,
                            VideoStreamingActivity.class);
                    storyInfo.setStoryMediaInfo(new StoryMediaInfo("", "mp4", "Video"));
                    myIntent.putExtra("storyInfo", storyInfo);
                    //  myIntent.putExtra("userProfile", userStoryProfile);
                    startActivity(myIntent);
                }

                if (initialY < finalY) {
                    Log.i(TAG, "onTouchEvent: SWIPE DOWN");  
                }

                if (initialY > finalY) {
                    Log.i(TAG, "onTouchEvent: SWIPE UP");
                }

                break;

            case MotionEvent.ACTION_CANCEL:
                Log.i(TAG, "onTouchEvent: ACTION_CANCEL");
                break;

            case MotionEvent.ACTION_OUTSIDE:
                Log.i(TAG, "onTouchEvent: ACTION_OUTSIDE");
                break;
        }

        return super.onTouchEvent(event);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG, "onCreate: ");
        permissionUtills=new PermissionUtills(this);
        telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        storyInfo=new StoryInfo();
        storyInfo= readPhoneState(storyInfo);
        storyInfo.setStoryobj(new StoryObj("caAS23f","cx5vJNuh8U","satyajit63","free"));
        storyInfo.setStoryContext(new StoryContext("br105","test","5","User"));
        storyInfo.setStoryMediaInfo(new StoryMediaInfo("","mp4","video"));

        player= (Button) findViewById(R.id.vw1);

//button Initialization code goes here


        player.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {

                Intent myIntent = new Intent(MainActivity.this,
                        StoryPlayListActivity.class);
                startActivity(myIntent);
            }
        });

        //button click listeners code goes here
    }


    private int checkPermission(int permission) {
        Log.d(TAG, "checkPermission: ");
        int status =PackageManager.PERMISSION_DENIED;
        switch (permission){
            case TXT_PHONE_STATE:
                status= ContextCompat.checkSelfPermission(this,Manifest.permission.READ_PHONE_STATE);
                break;
            case TXT_FINE_LOCATION:
                status=ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION);
                break;
            case TXT_COURSE_LOCATION:
                status=ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION);
        }
        return status;
    }

    private void requestPermission(int permission) {
        Log.d(TAG, "requestPermission: ");
        switch (permission){
            case TXT_PHONE_STATE:
                ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.READ_PHONE_STATE},REQUEST_PHONE_STATE);
                break;
            case TXT_FINE_LOCATION:
                ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQUEST_FINE_LOCATION);
                break;
            case TXT_COURSE_LOCATION:
                ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},REQUEST_COURSE_LOCATION);
                break;

        }

    }

    private void  showPermissionExplanation(final int permission){
        Log.d(TAG, "showPermissionExplanation: ");
        AlertDialog.Builder builder=new AlertDialog.Builder(this);

        if(permission==TXT_PHONE_STATE){
            builder.setMessage("This application access your Phone state...");
            builder.setTitle("Phone State Permission Needed");
        }
        if(permission==TXT_FINE_LOCATION){
            builder.setMessage("This application access your Location...");
            builder.setTitle("Location Permission Needed");
        }
        if(permission==TXT_COURSE_LOCATION){
            builder.setMessage("This application access your Course Location...");
            builder.setTitle("Location Permission Needed");
        }
        builder.setPositiveButton("Allow", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if(permission==TXT_PHONE_STATE){
                    requestPermission(TXT_PHONE_STATE);
                }
                if(permission==TXT_FINE_LOCATION){
                    requestPermission(TXT_FINE_LOCATION);
                }
                if(permission==TXT_COURSE_LOCATION){
                    requestPermission(TXT_COURSE_LOCATION);
                }
            }

        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog alertDialog=builder.create();
        alertDialog.show();
    }

   @TargetApi(Build.VERSION_CODES.O)
   private StoryInfo readPhoneState(StoryInfo story)  {
       Log.d(TAG, "readPhoneState: ");
        if(checkPermission(TXT_PHONE_STATE)!=PackageManager.PERMISSION_GRANTED){

           if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,Manifest.permission.READ_PHONE_STATE)) {
               showPermissionExplanation(TXT_PHONE_STATE);

           }
           else if (!permissionUtills.checkPermissionPreference("phone_state")){
               requestPermission(TXT_PHONE_STATE);
               permissionUtills.updatePermissionPreference("phone_state");
           }
           else
           {
               Toast.makeText(this,"Please Allow Phone State pemission in your app settings",Toast.LENGTH_SHORT).show();
               Intent intent=new Intent();
               intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
               Uri uri= Uri.fromParts("package",this.getPackageName(),null);
               intent.setData(uri);
               this.startActivity(intent);
           }
       }else if(checkPermission(TXT_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){

            if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,Manifest.permission.ACCESS_FINE_LOCATION)) {
                showPermissionExplanation(TXT_FINE_LOCATION);

            }
            else if (!permissionUtills.checkPermissionPreference("fine_location")){
                requestPermission(TXT_FINE_LOCATION);
                permissionUtills.updatePermissionPreference("fine_location");

            }
            else
            {
                Toast.makeText(this,"Please Allow Location pemission in your app settings",Toast.LENGTH_SHORT).show();
                Intent intent=new Intent();
                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri= Uri.fromParts("package",this.getPackageName(),null);
                intent.setData(uri);
                this.startActivity(intent);
            }
        } else if(checkPermission(TXT_COURSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){

            if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,Manifest.permission.ACCESS_COARSE_LOCATION)) {
                showPermissionExplanation(TXT_COURSE_LOCATION);

            }
            else if (!permissionUtills.checkPermissionPreference("course_location")){
                requestPermission(TXT_COURSE_LOCATION);
                permissionUtills.updatePermissionPreference("course_location");

            }
            else
            {
                Toast.makeText(this,"Please Allow Course Location pemission in your app settings",Toast.LENGTH_SHORT).show();
                Intent intent=new Intent();
                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri= Uri.fromParts("package",this.getPackageName(),null);
                intent.setData(uri);
                this.startActivity(intent);
            }
        }
        else{
            Toast.makeText(this,"You have already given pemission...",Toast.LENGTH_SHORT).show();
            String androidID = Settings.Secure.getString(MainActivity.this.getContentResolver(),
                    Settings.Secure.ANDROID_ID);
            Timestamp timestamp=new Timestamp(System.currentTimeMillis());

            gps = new GPSTracker(MainActivity.this);
            Location loc=null;
            // check if GPS enabled
            if(gps.canGetLocation()){

                double ltt = gps.getLatitude();
                double lng = gps.getLongitude();
                loc=new Location();
                loc.setLatitude(String.valueOf(ltt));
                loc.setLongitude(String.valueOf(lng));


            }else{
                // can't get location
                // GPS or Network is not enabled
                // Ask user to enable GPS/network in settings
                gps.showSettingsAlert();
            }
            Device device=new Device();
            device.setBrand(Build.BRAND);
            device.setModel(Build.MODEL);
            device.setType(String.valueOf(telephonyManager.getPhoneType()));
            List<Id> ids=new ArrayList<>();
            ids.add(new Id("IMEI",telephonyManager.getImei()));
            ids.add(new Id("Android_Id",Settings.Secure.getString(context.getContentResolver(),
                    Settings.Secure.ANDROID_ID)));
            /*ids.add(new Id("Hardware Serial Id",Build.getSerial()));*/
            ids.add(new Id("GSM Group Id",telephonyManager.getGroupIdLevel1()));
            /*ids.add(new Id("MEID",telephonyManager.getMeid()));*/

            device.setId(ids);
            //Timestamp,Location,Device,Os,network,sim
            story.setStoryDevice(new StoryDevice(
                    timestamp,
                    loc,
                    new Os("Android",Build.VERSION.RELEASE),
                    device
                    ,new Network(telephonyManager.getNetworkCountryIso(),"",telephonyManager.getNetworkOperatorName()),
                    new Sim(telephonyManager.getSubscriberId(),telephonyManager.getSimState(),telephonyManager.getSimOperatorName(),telephonyManager.getSimCountryIso())

            ));

        }
        return story;
    }
}
