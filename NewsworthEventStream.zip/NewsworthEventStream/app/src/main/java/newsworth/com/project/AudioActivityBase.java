package newsworth.com.project;

import android.Manifest;
import android.os.Bundle;
import android.widget.Button;

import com.wowza.gocoder.sdk.api.WowzaGoCoder;
import com.wowza.gocoder.sdk.api.devices.WOWZAudioDevice;
import com.wowza.gocoder.sdk.api.devices.WOWZCameraView;
import com.wowza.gocoder.sdk.api.graphics.WOWZColor;
import com.wowza.gocoder.sdk.api.logging.WOWZLog;

abstract public class AudioActivityBase extends GoCoderSDKActivityBase{
    protected WOWZAudioDevice mWZAudioDevice = null;
    protected Button mBtnBroadcast = null;
    private boolean mDevicesInitialized = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onResume() {
        super.onResume();
         this.hasDevicePermissionToAccess(new CameraActivityBase.PermissionCallbackInterface() {

            @Override
            public void onPermissionResult(boolean result) {
                if (!mDevicesInitialized || result) {
                    initGoCoderDevices();
                }
            }
        });

    }
    protected void initUIControls() {

        mBtnBroadcast= (Button)findViewById(R.id.broadcast_button);

        if (goCoder == null )
            WOWZLog.error(WowzaGoCoder.getLastError().getErrorDescription());
    }
    protected void initGoCoderDevices() {
        boolean audioIsInitialized = false;
        if(this.hasDevicePermissionToAccess(Manifest.permission.RECORD_AUDIO)) {
            // Initialize the audio input device interface
            mWZAudioDevice = new WOWZAudioDevice();

            // Set the audio broadcaster in the broadcast config
            getBroadcastConfig().setAudioBroadcaster(mWZAudioDevice);
            getBroadcastConfig().setVideoEnabled(false);
            audioIsInitialized = true;
        }
        if( audioIsInitialized)
            mDevicesInitialized = true;
    }

    protected boolean syncUIControlState() {
        boolean disableControls = (getBroadcast() == null ||
                !(getBroadcast().getStatus().isIdle() ||
                        getBroadcast().getStatus().isRunning()));
        boolean isStreaming = (getBroadcast() != null && getBroadcast().getStatus().isRunning());

        if (disableControls) {
            if (mBtnBroadcast != null) mBtnBroadcast.setEnabled(false);

        } else {
            if (mBtnBroadcast != null) {
                mBtnBroadcast.setEnabled(true);

            }
        }

        return disableControls;
    }

    //define callback interface
    interface PermissionCallbackInterface {

        void onPermissionResult(boolean result);
    }
}
