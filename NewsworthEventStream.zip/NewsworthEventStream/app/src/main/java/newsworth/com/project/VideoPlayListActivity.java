package newsworth.com.project;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.HandlerThread;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.DragEvent;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.newsworth.project.model.ElasticsearchResponse;
import com.newsworth.project.model.NWStoryView;
import com.newsworth.project.model.PlayListAdapter;
import com.newsworth.project.model.StoryMediaInfo;
import com.newsworth.project.model.VidItem;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import newsworth.com.project.adapter.OnSwipeTouchListener;


public class VideoPlayListActivity extends AppCompatActivity {

   private  List<NWStoryView> playList;
    private String json;
    Gson gson = new Gson();
    private static final String TAG ="";
    Float initialY,initialX;
private GestureDetector gestureDetector;

private View view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_play_list);
        populatePlayList();
        registerItemClickEvent();
    }

/*
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        System.out.println("VideoPlayListActivity : event occred is : "+event.getAction()+" : "+event.getActionMasked()+" : "+event.getRawX());
        return super.onTouchEvent(event);
    }
*/

    public void registerItemClickEvent() {
        ListView listView=(ListView) findViewById(R.id.playList);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String vidId=playList.get(position).getStoryId();
                Intent myIntent = new Intent(VideoPlayListActivity.this,
                        PlayerActivity.class);
                myIntent.putExtra("vidId",vidId);
                startActivity(myIntent);
            }
        });

        listView.setOnTouchListener(new OnSwipeTouchListener(this){
            @Override
            public void onSwipeRight() {
               /* super.onSwipeRight();*/
                System.out.println("Swipe Right..............--------------->>>>");

            }

            @Override
            public void onSwipeLeft() {
               /* super.onSwipeLeft();*/
                System.out.println("<<<<<-----------------------------Swipe Left");
                Intent myIntent = new Intent(VideoPlayListActivity.this,
                        MainActivity.class);
                startActivity(myIntent);
            }
        });
    }

    public void populatePlayList() {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);

        json = preferences.getString("playList", "");
        Type type=new TypeToken<List<NWStoryView>>(){}.getType();
        playList= gson.fromJson(json,type);

        List<NWStoryView> vidItemLIst= new ArrayList<>();
        System.out.println(playList);
        if(playList==null){
            new android.os.Handler().postDelayed(new Runnable() {
                @Override
                public void run() {

                    playList= Collections.singletonList(gson.fromJson(json, NWStoryView.class));
                    System.out.println(playList);
                }
            }, 3000);

        }else{

            PlayListAdapter adapter =new PlayListAdapter(this,playList) ;

            ListView listView=(ListView) findViewById(R.id.playList);
            listView.setAdapter(adapter);

         }
    }



}
