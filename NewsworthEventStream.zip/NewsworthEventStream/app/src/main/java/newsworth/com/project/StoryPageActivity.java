package newsworth.com.project;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.newsworth.project.model.NwCategory;
import com.newsworth.project.model.NwEvent;
import com.newsworth.project.model.StoryInfo;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import newsworth.com.project.service.RestCallStory;

public class StoryPageActivity extends AppCompatActivity {

    Button btn;
    private EditText title;
    private EditText description;
  //  private EditText category;
    private ToggleButton mode;
    private Spinner eventSp;
    private Spinner catSp;
    private StoryInfo story;
    private String storyTitle;
    private String storyDescription;

    private String userMode;

    RestCallStory restCallStory=new RestCallStory();
    private  List<NwEvent> playList;
    private List<NwCategory> catList;
    private String evJson;
    private String ctJson;
    Gson gson = new Gson();
    private String eventId;
    private Integer storyCategory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story_page);

        Bundle b = getIntent().getExtras();
        if (b != null) {
            story = (StoryInfo) getIntent().getExtras()
                    .getSerializable("nwStory");

        }
        System.out.println("========================>> Story Category : "+story);
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        evJson = preferences.getString("nwEventList", "");
        ctJson=preferences.getString("nwCatList", "");
        System.out.println("========================>> Event List : "+evJson);
        System.out.println("========================>> Category  List : "+ctJson);
        title = (EditText) findViewById(R.id.etTitle);
        description = (EditText) findViewById(R.id.etDescription);
      //  category = (EditText) findViewById(R.id.etCategory);
        mode = (ToggleButton) findViewById(R.id.tbUser);
        btn= (Button) findViewById(R.id.button);
        eventSp=(Spinner) findViewById(R.id.spEvent);
        catSp=(Spinner) findViewById(R.id.spCat);

        Type typeEv=new TypeToken<List<NwEvent>>(){}.getType();
        Type typeCt=new TypeToken<List<NwCategory>>(){}.getType();

        playList= gson.fromJson(evJson,typeEv);
        catList=gson.fromJson(ctJson,typeCt);
        System.out.println("========================>> Category  List Object: "+catList);
    List<String> events=new ArrayList<>();
    List<String> cats=new ArrayList<>();

        for (NwEvent e:playList) {
            events.add(e.getEventName().trim());
        }
        for (NwCategory ct:catList){
            cats.add(ct.getNewsCategoryName().trim());
        }

        System.out.println("========================>> Category  List Types: "+cats);
        if(playList==null){
            new android.os.Handler().postDelayed(new Runnable() {
                @Override
                public void run() {

                    playList= Collections.singletonList(gson.fromJson(evJson, NwEvent.class));

                }
            }, 3000);

        }else if( catList==null){
            new android.os.Handler().postDelayed(new Runnable() {
                @Override
                public void run() {

                    catList=Collections.singletonList(gson.fromJson(ctJson, NwCategory.class));

                }
            }, 3000);

        }else{

            eventSp.setAdapter(new ArrayAdapter<String>(StoryPageActivity.this, android.R.layout.simple_spinner_dropdown_item, events));
            catSp.setAdapter(new ArrayAdapter<String>(StoryPageActivity.this, android.R.layout.simple_spinner_dropdown_item, cats));
        }

        eventSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String eventName=   eventSp.getItemAtPosition(eventSp.getSelectedItemPosition()).toString();
                for(NwEvent ev:playList){
                    if(ev.getEventName().equals(eventName)){
                        eventId=ev.getEventId();
                    }
                }
                Toast.makeText(getApplicationContext(),eventName,Toast.LENGTH_LONG).show();
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                // DO Nothing here
            }
        });
        catSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String catName=   catSp.getItemAtPosition(catSp.getSelectedItemPosition()).toString();
                for(NwCategory ct:catList){
                    if(ct.getNewsCategoryName().equals(catName)){
                        storyCategory=ct.getNewsCategoryId();
                    }
                }
                Toast.makeText(getApplicationContext(),catName,Toast.LENGTH_LONG).show();
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                // DO Nothing here
            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                storyTitle=title.getText().toString();
                storyDescription=description.getText().toString();
              //  storyCategory=category.getText().toString();
                userMode=mode.getText().toString();
                System.out.println("Story is when came ---->" + storyTitle+" :: "+storyDescription+" :: "+storyCategory+" :: "+userMode);
                story.getStoryContext().setTitle(storyTitle);
                story.getStoryContext().setDescription(storyDescription);
                story.getStoryContext().setCategory(storyCategory.toString());
                story.getStoryContext().setPublishUnder(userMode);
                story.getStoryobj().setEventId(eventId);
                System.out.println("Story is and now ---->" + story);
                restCallStory.ServerCall(story);
                Intent intent = new Intent(StoryPageActivity.this,MainActivity.class);
                intent.putExtra("status", true);
                intent.putExtra("title", story.getStoryContext().getTitle());
                startActivity(intent);
            }
        });
    }


}
