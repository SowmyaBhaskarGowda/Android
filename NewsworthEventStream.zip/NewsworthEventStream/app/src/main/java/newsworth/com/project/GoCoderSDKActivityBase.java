package newsworth.com.project;

import android.app.Activity;
import android.app.FragmentManager;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.widget.Toast;

import com.google.gson.Gson;
import com.newsworth.project.model.UserStoryProfile;
import com.newsworth.project.model.com.newsworth.project.config.GoCoderSDKPrefs;
import com.wowza.gocoder.sdk.api.WowzaGoCoder;
import com.wowza.gocoder.sdk.api.broadcast.WOWZBroadcast;
import com.wowza.gocoder.sdk.api.broadcast.WOWZBroadcastConfig;
import com.wowza.gocoder.sdk.api.configuration.WOWZMediaConfig;
import com.wowza.gocoder.sdk.api.data.WOWZDataMap;
import com.wowza.gocoder.sdk.api.errors.WOWZError;
import com.wowza.gocoder.sdk.api.errors.WOWZStreamingError;
import com.wowza.gocoder.sdk.api.logging.WOWZLog;
import com.wowza.gocoder.sdk.api.status.WOWZStatus;
import com.wowza.gocoder.sdk.api.status.WOWZStatusCallback;

public abstract class GoCoderSDKActivityBase extends Activity
        implements WOWZStatusCallback {

    private final static String TAG = GoCoderSDKActivityBase.class.getSimpleName();


    private static final String SDK_SAMPLE_APP_LICENSE_KEY = "GOSK-A945-010C-42CA-2B0C-4DE9";
    // GoCoder SDK top level interface
    protected static WowzaGoCoder goCoder = null;
    protected WOWZBroadcast goCoderBroadcaster;
    protected WOWZBroadcastConfig goCoderBroadcastConfig;
    private CameraActivityBase.PermissionCallbackInterface callbackFunction = null;
    private static final int PERMISSIONS_REQUEST_CODE = 0x1;
    protected String[] mRequiredPermissions = {};
    protected boolean mPermissionsGranted = false;
    private boolean hasRequestedPermissions = false;
    protected UserStoryProfile userStoryProfile;

    private static Object sBroadcastLock = new Object();
    private static boolean sBroadcastEnded = true;


    public WOWZBroadcastConfig getBroadcastConfig() {
        return goCoderBroadcastConfig;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        goCoder = WowzaGoCoder.init(getApplicationContext(), SDK_SAMPLE_APP_LICENSE_KEY);
        Log.d(TAG, "onCreate: ");
        if (goCoder == null) {
            // If initialization failed, retrieve the last error and display it
            WOWZError goCoderInitError = WowzaGoCoder.getLastError();
            Toast.makeText(this,
                    "GoCoder SDK error: " + goCoderInitError.getErrorDescription(),
                    Toast.LENGTH_LONG).show();
            return;
        }
        goCoderBroadcaster = new WOWZBroadcast();
        goCoderBroadcaster.setLogLevel(WOWZLog.LOG_LEVEL_DEBUG);

        goCoderBroadcastConfig = new WOWZBroadcastConfig(getFrameRate()/*WOWZMediaConfig.FRAME_SIZE_640x480*/);

    }
    public void syncPreferences() {
        Log.d(TAG, "syncPreferences: ");
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);

        if (goCoderBroadcastConfig != null)
            GoCoderSDKPrefs.updateConfigFromPrefs(prefs, goCoderBroadcastConfig);
    }
    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: ");
        mPermissionsGranted = this.hasDevicePermissionToAccess();
        if (mPermissionsGranted){
            syncPreferences();
        }

    }
    @Override
    protected void onPause() {
        Log.d(TAG, "onPause: ");
        // Stop any active live stream
        if (goCoderBroadcaster != null && goCoderBroadcaster.getStatus().isRunning()) {
            endBroadcast(true);
        }

        super.onPause();
    }
    // Return correctly from any fragments launched and placed on the back stack
    @Override
    public void onBackPressed(){
        Log.d(TAG, "onBackPressed: ");
        FragmentManager fm = getFragmentManager();
        if (fm.getBackStackEntryCount() > 0) {
            fm.popBackStack();
        }
        else {
            super.onBackPressed();
        }
    }

    private WOWZMediaConfig getFrameRate() {
        Log.d(TAG, "getFrameRate: ");
        userStoryProfile=new UserStoryProfile();


        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        Gson gson = new Gson();
        String json = preferences.getString("userConf", "");
        userStoryProfile = gson.fromJson(json, UserStoryProfile.class);
        System.out.println(userStoryProfile);
        String frameRate = userStoryProfile.getVideoProfile().getQuality();
        WOWZMediaConfig wOWZMediaConfig = new WOWZMediaConfig();

        switch (frameRate) {
            case "FRAME_SIZE_176x144":
                wOWZMediaConfig = WOWZMediaConfig.FRAME_SIZE_176x144;
                break;
            case "FRAME_SIZE_320x240":
                wOWZMediaConfig = WOWZMediaConfig.FRAME_SIZE_320x240;
                break;
            case "FRAME_SIZE_352x288":
                wOWZMediaConfig = WOWZMediaConfig.FRAME_SIZE_352x288;
                break;
            case "FRAME_SIZE_640x480":
                wOWZMediaConfig = WOWZMediaConfig.FRAME_SIZE_640x480;
                break;
            case "FRAME_SIZE_960x540":
                wOWZMediaConfig = WOWZMediaConfig.FRAME_SIZE_960x540;
                break;
            case "FRAME_SIZE_1280x720":
                wOWZMediaConfig = WOWZMediaConfig.FRAME_SIZE_1280x720;
                break;
            case "FRAME_SIZE_1440x1080":
                wOWZMediaConfig = WOWZMediaConfig.FRAME_SIZE_1440x1080;
                break;
            case "FRAME_SIZE_1920x1080":
                wOWZMediaConfig = WOWZMediaConfig.FRAME_SIZE_1920x1080;
                break;
            case "FRAME_SIZE_3840x2160":
                wOWZMediaConfig = WOWZMediaConfig.FRAME_SIZE_3840x2160;
                break;
            default:
                wOWZMediaConfig = null;
                break;
        }
        return wOWZMediaConfig;
    }

    protected void hasDevicePermissionToAccess(CameraActivityBase.PermissionCallbackInterface callback){
        Log.d(TAG, "hasDevicePermissionToAccess: ");
        this.callbackFunction = callback;
        if (goCoderBroadcaster != null) {
            boolean result = true;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                result = (mRequiredPermissions.length > 0 ? WowzaGoCoder.hasPermissions(this, mRequiredPermissions) : true);
                if (!result && !hasRequestedPermissions) {
                    ActivityCompat.requestPermissions(this, mRequiredPermissions, PERMISSIONS_REQUEST_CODE);
                    hasRequestedPermissions = true;
                }
                else {
                    this.callbackFunction.onPermissionResult(result);
                }
            }
            else {
                this.callbackFunction.onPermissionResult(result);
            }
        }
    }
    public WOWZBroadcast getBroadcast() {
        Log.d(TAG, "getBroadcast: ");
        return goCoderBroadcaster;
    }
    protected boolean hasDevicePermissionToAccess(String source){
        Log.d(TAG, "hasDevicePermissionToAccess: ");
        String[] permissionRequestArr = new String[] {
                source
        };
        boolean result = false;
        if (goCoderBroadcaster != null) {
            result = true;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                result = (mRequiredPermissions.length > 0 ? WowzaGoCoder.hasPermissions(this, permissionRequestArr) : true);
            }
        }
        return result;
    }

    protected boolean hasDevicePermissionToAccess(){
        Log.d(TAG, "hasDevicePermissionToAccess: ");
        boolean result = false;
        if (goCoderBroadcaster != null) {
            result = true;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                result = (mRequiredPermissions.length > 0 ? WowzaGoCoder.hasPermissions(this, mRequiredPermissions) : true);
                if (!result && !hasRequestedPermissions) {
                    ActivityCompat.requestPermissions(this, mRequiredPermissions, PERMISSIONS_REQUEST_CODE);
                    hasRequestedPermissions = true;
                }
            }
        }
        return result;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        Log.d(TAG, "onRequestPermissionsResult: ");
        mPermissionsGranted = true;
        switch (requestCode) {
            case PERMISSIONS_REQUEST_CODE: {
                for(int grantResult : grantResults) {
                    if (grantResult != PackageManager.PERMISSION_GRANTED) {
                        mPermissionsGranted = false;
                    }
                }
            }
        }
        if(this.callbackFunction!=null)
            this.callbackFunction.onPermissionResult(mPermissionsGranted);
    }
    protected synchronized WOWZStreamingError startBroadcast() {
        Log.d(TAG, "startBroadcast: ");
        WOWZStreamingError configValidationError = null;

        if (goCoderBroadcaster.getStatus().isIdle()) {
            Log.d(TAG, "startBroadcast: broadcast status is idle ");

            //
            // An example of adding metadata values to the stream for use with the onMetadata()
            // method of the IMediaStreamActionNotify2 interface of the Wowza Streaming Engine Java
            // API for server modules.
            //
            // See http://www.wowza.com/resources/serverapi/com/wowza/wms/stream/IMediaStreamActionNotify2.html
            // for additional usage information on IMediaStreamActionNotify2.
            //

            // Add stream metadata describing the current device and platform
            WOWZDataMap streamMetadata = new WOWZDataMap();
            streamMetadata.put("androidRelease", Build.VERSION.RELEASE);
            streamMetadata.put("androidSDK", Build.VERSION.SDK_INT);
            streamMetadata.put("deviceProductName", Build.PRODUCT);
            streamMetadata.put("deviceManufacturer", Build.MANUFACTURER);
            streamMetadata.put("deviceModel", Build.MODEL);

            goCoderBroadcastConfig.setStreamMetadata(streamMetadata);

            //
            // An example of adding query strings for use with the getQueryStr() method of
            // the IClient interface of the Wowza Streaming Engine Java API for server modules.
            //
            // See http://www.wowza.com/resources/serverapi/com/wowza/wms/client/IClient.html#getQueryStr()
            // for additional usage information on getQueryStr().
            //
            try {
                PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);

                // Add query string parameters describing the current app
                WOWZDataMap connectionParameters = new WOWZDataMap();
                connectionParameters.put("appPackageName", pInfo.packageName);
                connectionParameters.put("appVersionName", pInfo.versionName);
                connectionParameters.put("appVersionCode", pInfo.versionCode);

                goCoderBroadcastConfig.setConnectionParameters(connectionParameters);

            } catch (PackageManager.NameNotFoundException e) {
                WOWZLog.error(TAG, e);
            }

            WOWZLog.info(TAG, "=============== Broadcast Configuration ===============\n"
                    + goCoderBroadcastConfig.toString()
                    + "\n=======================================================");


            configValidationError = goCoderBroadcastConfig.validateForBroadcast();

            if (configValidationError == null) {


                /// Setup abr bitrate and framerate listeners. EXAMPLE
//                mWZBroadcastConfig.setABREnabled(false);
//                ListenToABRChanges abrHandler = new ListenToABRChanges();
//                mWZBroadcast.registerAdaptiveBitRateListener(abrHandler);
//                mWZBroadcast.registerAdaptiveFrameRateListener(abrHandler);
//                mWZBroadcastConfig.setFrameRateLowBandwidthSkipCount(1);

                goCoderBroadcaster.startBroadcast(goCoderBroadcastConfig, this);

            }
        } else {
            WOWZLog.error(TAG, "startBroadcast() called while another broadcast is active");
        }
        return configValidationError;
    }
    protected synchronized void endBroadcast(boolean appPausing) {
        WOWZLog.debug("MP4","endBroadcast");
        if (!goCoderBroadcaster.getStatus().isIdle()) {
            WOWZLog.debug("MP4","endBroadcast-notidle");
            if (appPausing) {
                // Stop any active live stream
                sBroadcastEnded = false;
                goCoderBroadcaster.endBroadcast(new WOWZStatusCallback() {
                    @Override
                    public void onWZStatus(WOWZStatus wzStatus) {
                        WOWZLog.debug("MP4","onWZStatus::"+wzStatus.toString());
                        synchronized (sBroadcastLock) {
                            sBroadcastEnded = true;
                            sBroadcastLock.notifyAll();
                        }
                    }

                    @Override
                    public void onWZError(WOWZStatus wzStatus) {
                        WOWZLog.debug("MP4","onWZStatus::"+wzStatus.getLastError());
                        WOWZLog.error(TAG, wzStatus.getLastError());
                        synchronized (sBroadcastLock) {
                            sBroadcastEnded = true;
                            sBroadcastLock.notifyAll();
                        }
                    }
                });

                while(!sBroadcastEnded) {
                    try{
                        sBroadcastLock.wait();
                    } catch (InterruptedException e) {}
                }
            } else {
                goCoderBroadcaster.endBroadcast(this);
            }
        }  else {
            WOWZLog.error(TAG, "endBroadcast() called without an active broadcast");
        }
    }

    protected synchronized void endBroadcast() {
        endBroadcast(false);
    }

		}